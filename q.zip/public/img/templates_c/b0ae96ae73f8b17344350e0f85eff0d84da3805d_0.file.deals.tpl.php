<?php
/* Smarty version 3.1.29, created on 2018-10-13 11:03:08
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/deals.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5bc1a6bc378c28_30764916',
  'file_dependency' => 
  array (
    'b0ae96ae73f8b17344350e0f85eff0d84da3805d' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/deals.tpl',
      1 => 1539417786,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bc1a6bc378c28_30764916 ($_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['deals']->value) {?>

<?php }?>

<div class="playlist-box">
M Team
</div><?php }
}

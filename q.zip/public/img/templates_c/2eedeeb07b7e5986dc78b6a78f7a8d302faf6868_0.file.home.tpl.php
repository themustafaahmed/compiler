<?php
/* Smarty version 3.1.29, created on 2017-08-01 14:32:20
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/home.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_598066c4869008_08756965',
  'file_dependency' => 
  array (
    '2eedeeb07b7e5986dc78b6a78f7a8d302faf6868' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/home.tpl',
      1 => 1501587139,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:popular.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_598066c4869008_08756965 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:popular.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

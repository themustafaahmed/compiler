<?php
/* Smarty version 3.1.29, created on 2017-06-15 13:20:37
  from "/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_59425f755e8af1_81136774',
  'file_dependency' => 
  array (
    '0820e3048da46d76fec472ad8395e3a3856cce92' => 
    array (
      0 => '/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/header.tpl',
      1 => 1497522029,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:top.tpl' => 1,
  ),
),false)) {
function content_59425f755e8af1_81136774 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title>MP3 - Download</title>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/bootstrap.css?ver=1">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/noty.css?ver=1">
</head>
<body>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:top.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

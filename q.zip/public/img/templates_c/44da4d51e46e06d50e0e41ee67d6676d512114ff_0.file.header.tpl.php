<?php
/* Smarty version 3.1.29, created on 2017-07-20 21:22:52
  from "/Users/clear/Programing/projects/repeat.bg/templates/header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5970f4fcaa2a42_79308201',
  'file_dependency' => 
  array (
    '44da4d51e46e06d50e0e41ee67d6676d512114ff' => 
    array (
      0 => '/Users/clear/Programing/projects/repeat.bg/templates/header.tpl',
      1 => 1500574868,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5970f4fcaa2a42_79308201 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title><?php echo $_smarty_tpl->tpl_vars['seo']->value['title'];?>
</title>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/bootstrap.css">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/ion.rangeSlider.css">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/ion.rangeSlider.skinFlat.css">
</head>
<body>

<header>
	<div class="container align-items-center py-2">
		<div class="flex">
			<div class="dropdown">
			  <button class="btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			    <img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/menu-icon.png">
			  </button>
			  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
			    <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/how">How it works</a>
			    <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/contact-us">Contacts us</a>
			  </div>
			</div>

			<h1 class="logo">
				<img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/logo.png" alt="">
			</h1>
			
			<div class="input-group">
			    <div class="input-group-addon"><i class="fa fa-search" aria-hidden="true"></i></div>
			    <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Search...">
			</div>
		</div>
	</div>
</header><?php }
}

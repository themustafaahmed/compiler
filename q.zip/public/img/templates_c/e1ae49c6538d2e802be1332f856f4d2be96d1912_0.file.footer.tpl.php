<?php
/* Smarty version 3.1.29, created on 2017-07-20 21:19:41
  from "/Users/clear/Programing/projects/repeat.bg/templates/footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5970f43dcb1ea6_65969676',
  'file_dependency' => 
  array (
    'e1ae49c6538d2e802be1332f856f4d2be96d1912' => 
    array (
      0 => '/Users/clear/Programing/projects/repeat.bg/templates/footer.tpl',
      1 => 1500574774,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5970f43dcb1ea6_65969676 ($_smarty_tpl) {
?>
	<footer class="py-4">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-md-4">
					<small>Copyright (c) 2017 Repeat. All Rights Reserved.</small>
				</div>
				<div class="col-md-2">
					<a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
">
						<img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/logo.png" alt="">
					</a>
				</div>
				<div class="col-md-3 text-right">
					<a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/contact-us"><small>Contact & Support</small></a>
				</div>
			</div>
		</div>
	</footer>

<?php echo '<script'; ?>
 src="https://www.youtube.com/iframe_api"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/jquery-1.11.2.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/jquery.mCustomScrollbar.concat.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/tether.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/bootstrap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/owl.carousel.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/ion.rangeSlider.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/custom.js"><?php echo '</script'; ?>
>
</body>
</html><?php }
}

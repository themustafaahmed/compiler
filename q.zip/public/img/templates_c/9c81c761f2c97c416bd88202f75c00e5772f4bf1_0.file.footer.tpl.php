<?php
/* Smarty version 3.1.29, created on 2018-10-13 10:57:46
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5bc1a57a11b194_03723616',
  'file_dependency' => 
  array (
    '9c81c761f2c97c416bd88202f75c00e5772f4bf1' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/footer.tpl',
      1 => 1539417452,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bc1a57a11b194_03723616 ($_smarty_tpl) {
?>
</main>
	<footer class="py-4">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-md-4">
					<small>Copyright (c) 2018 Repeat. All Rights Reserved.</small>
				</div>
				<div class="col-md-2">
					<a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
">
						<img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/logo.png" alt="">
					</a>
				</div>
				<div class="col-md-3 text-right">
					<a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/contact-us/"><small>Contact & Support</small></a>
				</div>
			</div>
		</div>
	</footer>

<?php echo '<script'; ?>
 type="text/javascript">
	var videoID = "<?php if ($_smarty_tpl->tpl_vars['videoInfo']->value['videoID']) {
echo $_smarty_tpl->tpl_vars['videoInfo']->value['videoID'];
} else { ?>0<?php }?>";
	var baseURL = "<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
";
<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="https://www.youtube.com/iframe_api"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/jquery-1.11.2.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/jquery.mCustomScrollbar.concat.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/tether.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/bootstrap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/owl.carousel.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/ion.rangeSlider.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/noty.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/custom.js?ver=<?php echo $_smarty_tpl->tpl_vars['timestamp']->value;?>
"><?php echo '</script'; ?>
>
</body>
</html><?php }
}

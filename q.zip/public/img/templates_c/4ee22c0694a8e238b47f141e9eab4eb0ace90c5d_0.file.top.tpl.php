<?php
/* Smarty version 3.1.29, created on 2017-06-15 13:31:05
  from "/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/top.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_594261e9490261_41574036',
  'file_dependency' => 
  array (
    '4ee22c0694a8e238b47f141e9eab4eb0ace90c5d' => 
    array (
      0 => '/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/top.tpl',
      1 => 1497522652,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_594261e9490261_41574036 ($_smarty_tpl) {
?>
<header class="header-home">
    <?php if ($_smarty_tpl->tpl_vars['current_index']->value != 'page') {?>
      <div class="sonar-emitter animated"></div>
      <div class="igla"></div>
    <?php }?>
    <a href="#" class="contain-icon icon-hook">

	<div class="container">
      <div class="dropdown hidden-sm-up">
        <a class="nav-link dropdown-toggle" 
           data-toggle="dropdown" 
           href="#" 
           role="button" 
           id="dropdownMenuButton" 
           aria-haspopup="true" 
           aria-expanded="false"> <i class="fa fa-bars" aria-hidden="true"></i></a>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
          <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
">Home</a>
          <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/contact">Contact</a>
          <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/about-us">About us</a>
          <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/privacy-policy">Privacy Policy</a>
          <a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/how">How to use</a>
        </div>
      </div>

        <ul class="nav justify-content-center main-nav hidden-xs-down">
          <li class="nav-item">
            <a class="nav-link active" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/contact">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/about-us">About us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/privacy-policy">Privacy Policy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/how">How to use</a>
          </li>
        </ul> 
    
      <?php if ($_smarty_tpl->tpl_vars['current_index']->value == 'download') {?>

      <div class="song-box row justify-content-center">
        <div class="col-lg-4 col-md-6">
          <div class="flex-box">        
                <figure class="img-video"><img src="<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['thumbnail'];?>
?custom=true&w=336&h=188&stc=true&jpg444=true&jpgq=90&sp=68&sigh=Y57BcpksHM8l_EAmnL63g0zVtMQ" alt=""></figure>
                <span class="title-one d-nline-block"><?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['title'];?>
</span>
            </div>
          <div class="dropbox">Send to: <a class="dropbox-sa" href="#"><i class="fa fa-dropbox" aria-hidden="true"></i> Dropbox</a></div>
        </div>
        <div class="col-lg-4 col-md-6">
            <?php if ($_smarty_tpl->tpl_vars['hideDownloadBtn']->value) {?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/download/force?t=<?php echo $_smarty_tpl->tpl_vars['encrypted']->value['title'];?>
&v=<?php echo $_smarty_tpl->tpl_vars['encrypted']->value['youtube_id'];?>
" class="btn btn-primary mx-2 btn-longer">Download</a>
            <br>
            <a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
" class="btn btn-primary-two mx-2 btn-longer">Listen on Repeat</a>
            <br>
            <?php }?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
" class="btn btn-primary-two mx-2 btn-longer">Back to Home</a>

            
        </div>
      </div>
      <?php }?>
      <?php if ($_smarty_tpl->tpl_vars['current_index']->value == 'index') {?>
    	<div class="home-convert-box mx-auto">
        
        	<span class="title-one d-nline-block">WELCOME</span>
          <span class="title-two d-block">CONVERT FROM<br>YOUTUBE TO MP3</span> 
          <span class="title-three d-block py-3">online service for <br>converting videos to mp3</span> 

          <form class="form-inline convert-box pb-3" method="post" id="convert_form"> 
              <div class="form-group mr-3"><input id="videoUrl" type="text" name="url" class="form-control" placeholder="http://www.youtube.com/watch?v=KMU0tzLwhbE"></div>
              <input type="hidden" class="form-control" id="inlineFormInputGroup" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
              <button type="submit" class="btn btn-primary mx-2 convert"><span>Convert </span><i class="fa fa-refresh" aria-hidden="true"></i></button>

          </form>
      </div>
      <?php }?>
    </div>                          
</a></header>
<?php }
}

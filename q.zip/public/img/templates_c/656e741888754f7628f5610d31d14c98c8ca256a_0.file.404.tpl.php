<?php
/* Smarty version 3.1.29, created on 2017-04-19 10:41:37
  from "/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/404.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_58f714b12ae2f3_23128177',
  'file_dependency' => 
  array (
    '656e741888754f7628f5610d31d14c98c8ca256a' => 
    array (
      0 => '/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/404.tpl',
      1 => 1492352053,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_58f714b12ae2f3_23128177 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

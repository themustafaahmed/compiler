<?php
/* Smarty version 3.1.29, created on 2017-06-14 18:36:53
  from "/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_59415815208db7_62239653',
  'file_dependency' => 
  array (
    '64e1d8631e5a538807348499e9ceac347e8abbba' => 
    array (
      0 => '/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/footer.tpl',
      1 => 1497454608,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59415815208db7_62239653 ($_smarty_tpl) {
?>
	<footer class="footer-index pb-4">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-10">
					<ul class="nav footer-main-nav">
			          <li class="nav-item">
			            <a class="nav-link active" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
">Home</a>
			          </li>
			          <li class="nav-item">
			            <a class="nav-link active" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/contact">Contact</a>
			          </li>
			          <li class="nav-item">
			            <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/about-us">About us</a>
			          </li>
			          <li class="nav-item">
			            <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/privacy-policy">Privacy Policy</a>
			          </li>
			          <li class="nav-item">
			            <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/page/how">How to use</a>
			          </li>
			        </ul>
			        <span>Vibbi is not endorsed or certified by Instagram. All Instagram™ logos and trademarks displayed on this application are property of Instagram.</span>
				</div>
			</div>
		</div>
	</footer>


<?php echo '<script'; ?>
 type="text/javascript">
	var baseURL = '<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
';
<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/jquery-1.11.2.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/tether.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/bootstrap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/custom.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['js'];?>
/noty.min.js"><?php echo '</script'; ?>
>


<?php echo '<script'; ?>
 type="text/javascript">

	$(".most-popular-videos").click(function() {
		var videoUrl = $(this).attr('data-url');
		
		$('#videoUrl').attr('placeholder', '');
		$('#videoUrl').val(videoUrl);
		$('#convert_form').submit();

	});

<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 type="text/javascript" src="https://www.dropbox.com/static/api/2/dropins.js" id="dropboxjs" data-app-key="fbnlt6gpdn29x5r"><?php echo '</script'; ?>
>

 <?php if ($_smarty_tpl->tpl_vars['current_index']->value == 'download') {?>

<?php echo '<script'; ?>
 type="text/javascript">

	var dropBoxUrl = '<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/download/force?t=<?php echo $_smarty_tpl->tpl_vars['encrypted']->value['title'];?>
&v=<?php echo $_smarty_tpl->tpl_vars['encrypted']->value['youtube_id'];?>
';
	var dropBoxTitle = '<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['title_save'];?>
.mp3';

	
	$(document).ready(function(){

		$(function(){
			var options = {
				files: [
					{'url': dropBoxUrl, 'filename': dropBoxTitle}
				],
				success: function () {
					new Noty({
						type: 'success',
						closeWith: ['click', 'button'],
    					text: 'File has been saved to your Dropbox successfully!',
					}).show();
				},
				progress: function (progress) {},
				cancel: function () {},
				error: function (errorMessage) {
					new Noty({
    					text: errorMessage,
    					type: 'error'
					}).show();
				}
			};

			var button = Dropbox.createSaveButton(options);
			$('.dropbox-sa').append(button);
		});
	});

	

<?php echo '</script'; ?>
>

<?php }?>


</body>
</html><?php }
}

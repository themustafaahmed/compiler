<?php
/* Smarty version 3.1.29, created on 2018-11-05 10:29:55
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/watch.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5bdfff8394ff32_46971179',
  'file_dependency' => 
  array (
    'ad3223ecc797e7d161af9fbde5a9bfc7acf25b3b' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/watch.tpl',
      1 => 1541406595,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:related.tpl' => 1,
    'file:popular.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5bdfff8394ff32_46971179 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_iso8601_duration')) require_once '/var/wwwprefix/projects/_framework/libs/smarty/plugins/modifier.iso8601_duration.php';
if (!is_callable('smarty_modifier_date_format')) require_once '/var/wwwprefix/projects/_framework/libs/smarty/plugins/modifier.date_format.php';
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<div class="container pt-5" itemprop="video" itemscope itemtype="http://schema.org/VideoObject">
	<div class="main-video-box mb-4">

		<div class="video-left-info">
			<div class="video">
			   <div class="video_inside"><div id="player" style="min-height: 430px;background-color: #f1f1f1;text-align: center;"><span style="color:#ccc;line-height: 430px;">Loading youtube iframe... (Refresh after 5 sec)</span></div></div>
			</div>

			<div class="flex-download-btn py-3 shrink_ten">
			<div class="contaoler">
					<div id="range" data-range_min="0" data-cur_min="0"></div>
				</div>

			</div>

			<div class="cd-popup" role="alert">
				<div class="cd-popup-container">
					<p>What do you want to convert to mp3?</p>
					<ul class="cd-buttons">
						<li><a target="_blank" href="http://youtubemp3.eurocoders.com/repeat/<?php echo $_smarty_tpl->tpl_vars['encryptedToken']->value;?>
">Full video</a></li>
						<li><a target="_blank" href="javascript:;" class="encrypt_range">Selected Range</a></li>
					</ul>
					<a href="#0" class="cd-popup-close img-replace">Close</a>
				</div> <!-- cd-popup-container -->
			</div> <!-- cd-popup -->

			<div class="flex-download-btn py-3 pt_none">
				
				<div id="stats">
					<span class="span">Total Loops: <strong id="countLoops">0</strong></span>
				</div>
				
				<div>
					<span class="span">Download as MP3 YouTube Downloader</span>
					<a href="" class="btn btn-download cd-popup-trigger"><img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/download-btn.png" alt="">Download</a>
				</div>
			</div>	

			<article class="video-title py-4 px-3">
				<div class="title-left">
					<h1 itemprop="name"><?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['title'];?>
</h1>

					<meta itemprop="thumbnailUrl" content="https://i.ytimg.com/vi/<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['videoID'];?>
/mqdefault.jpg" />
					<meta itemprop="duration" content="<?php echo smarty_modifier_iso8601_duration($_smarty_tpl->tpl_vars['videoInfo']->value['duration']);?>
">

					<div class="author">
						<figure>
							<img src="<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['uploaderAvatar'];?>
" alt="">
						</figure>
						<h2><?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['uploader'];?>

						<span itemprop="uploadDate">Published on <?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['videoInfo']->value['upload_date']);?>
</span></h2>

						
						<div class="title-right">
							<nav class="nav social">
							  <a class="nav-link js-sharer" data-service="facebook" data-id="<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['videoID'];?>
" href="javascript:;"><i class="fa fa-facebook" aria-hidden="true"></i></a>
							  <a class="nav-link js-sharer" data-service="twitter" data-id="<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['videoID'];?>
" href="javascript:;"><i class="fa fa-twitter" aria-hidden="true"></i></a>
							  <a class="nav-link js-sharer" data-service="google+" data-id="<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['videoID'];?>
" href="javascript:;"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
							  <a class="nav-link js-sharer" data-service="reddit" data-id="<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['videoID'];?>
" href="javascript:;"><i class="fa fa-reddit-alien" aria-hidden="true"></i></a>
							  <a class="nav-link js-sharer" data-service="tumblr" data-id="<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['videoID'];?>
" href="javascript:;"><i class="fa fa-tumblr" aria-hidden="true"></i></a>
							  <a class="nav-link js-sharer" data-service="pinterest" data-id="<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['videoID'];?>
" href="javascript:;"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
							</nav>
						</div>
					</div>

					<p itemprop="description" class="m-0 py-2 descr">Play your favorite YouTube video <?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['title'];?>
 on <?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['name'];?>
</p>

				</div>
			</article>	
		</div>
		
		
		
		<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:related.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


	</div>
	
</div>

		<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:popular.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php echo '<script'; ?>
 type="text/javascript">
	var videoDuration = "<?php echo $_smarty_tpl->tpl_vars['videoInfo']->value['duration'];?>
";
	var encryptedToken = "<?php echo $_smarty_tpl->tpl_vars['encryptedToken']->value;?>
";
<?php echo '</script'; ?>
>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

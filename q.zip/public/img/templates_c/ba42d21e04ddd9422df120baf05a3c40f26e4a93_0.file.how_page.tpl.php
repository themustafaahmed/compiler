<?php
/* Smarty version 3.1.29, created on 2017-06-14 11:08:44
  from "/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/pages/how_page.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5940ef0c62d1e1_75782568',
  'file_dependency' => 
  array (
    'ba42d21e04ddd9422df120baf05a3c40f26e4a93' => 
    array (
      0 => '/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/pages/how_page.tpl',
      1 => 1497416728,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5940ef0c62d1e1_75782568 ($_smarty_tpl) {
?>
<section class="container main">
  <div class="row py-5 justify-content-center">
    <div class="col-md-10">
      <div class="row">

        <div class="col-md-5">
          <span class="about-us pl-2">About<small>us</small></span>
        </div>

        <div class="col-md-7">
          <p>  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      
            <p>It has survived not only five centuries, but also the leap into electronic typesetting.</p>
            <a href="#">mail@to.me</a>
        </div>

      </div>

      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p>

    </div>
  </div>
</section><?php }
}

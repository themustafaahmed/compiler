<?php
/* Smarty version 3.1.29, created on 2018-04-24 13:12:25
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5adf0309633139_48241101',
  'file_dependency' => 
  array (
    '45fb7c1a2c16b5a66cae1c9c19deab1e07f48594' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/header.tpl',
      1 => 1524564743,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5adf0309633139_48241101 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title><?php echo $_smarty_tpl->tpl_vars['seo']->value['title'];?>
</title>

    <?php if ($_smarty_tpl->tpl_vars['seo']->value['description']) {?>
        <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['seo']->value['description'];?>
"/>
    <?php } else { ?>
        <meta name="description" content="A page's description, 
      usually one or two sentences."/>
    <?php }?> 

    <?php if ($_smarty_tpl->tpl_vars['seo']->value['keywords']) {?>
    <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['seo']->value['keywords'];?>
">
    <?php }?>
    <?php if ($_smarty_tpl->tpl_vars['noindex']->value) {?>
    <meta name="robots" content="noindex, follow">
    <?php } else { ?>
    <meta name="robots" content="noindex, nofollow">
    <?php }?>

    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/bootstrap.css?ver=<?php echo $_smarty_tpl->tpl_vars['timestamp']->value;?>
">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/noty.css?ver=<?php echo $_smarty_tpl->tpl_vars['timestamp']->value;?>
">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/ion.rangeSlider.css?ver=<?php echo $_smarty_tpl->tpl_vars['timestamp']->value;?>
">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['css'];?>
/ion.rangeSlider.skinFlat.css?ver=<?php echo $_smarty_tpl->tpl_vars['timestamp']->value;?>
">

    <link rel="canonical" href="<?php echo $_smarty_tpl->tpl_vars['currentUrl']->value;?>
">

</head>
<body <?php if ($_smarty_tpl->tpl_vars['currentPage']->value == 'index') {?>class="home"<?php }?>>

<header>
	<div class="container align-items-center py-2">
		<div class="flex">
			<div class="dropdown">
			  <a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			    <img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/menu-icon-white.png" alt="">
			  </a>
			  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
			    <a class="dropdown-item" href="#">Action</a>
			    <a class="dropdown-item" href="#">Another action</a>
			    <a class="dropdown-item" href="#">Something else here</a>
			  </div>
			</div>
			<?php if ($_smarty_tpl->tpl_vars['currentPage']->value == 'index') {?>
			<a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
" class="logo">
				<img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/logo-white.png" alt="">
			</a>
			<?php } else { ?>
			<a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
" class="logo">
				<img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/logo.png" alt="">
			</a>
			<?php }?>

			<?php if ($_smarty_tpl->tpl_vars['currentPage']->value != 'index') {?>
			<form id="searchForm" class="input-group" method="post" action="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/ajax/fetch/">
			    <div class="input-group-addon"><i class="fa fa-search" aria-hidden="true"></i></div>
			    <input type="hidden" class="form-control" name="token" value="<?php echo $_smarty_tpl->tpl_vars['commonToken']->value;?>
">
			    <input type="text" class="form-control" id="inlineFormInputGroup" name="url" placeholder="e.g.: http://www.youtube.com/watch?v=KMU0tzLwhbE">
			</form>
			<?php }?>
		</div>
		<?php if ($_smarty_tpl->tpl_vars['currentPage']->value == 'index') {?>
        <div class="home-top-box text-center">
        	<h1>Repeat YouTube videos<br>automatically</h1>
            <span>Repeat YouTube videos, crop your favorite part of a video, create Playlists on the fly and save videos to your Bookmarks list. No accounts, no downloads, just music</span>
            
            <form id="searchForm" class="input-group mt-4" method="post" action="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/ajax/fetch/">
            	<input type="hidden" class="form-control" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
">
                <input type="text" name="url" class="form-control" placeholder="e.g.: http://www.youtube.com/watch?v=KMU0tzLwhbE">
                <div class="input-group-addon">
                <button type="submit" class="btn-repeat">
                	<img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/search.png" alt="">
                </button>
                </div>
            </div>
        </div>
        <?php }?>
	</div>
</header>
<main><?php }
}

<?php
/* Smarty version 3.1.29, created on 2017-06-14 17:51:23
  from "/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/popular.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_59414d6b23cb41_35298577',
  'file_dependency' => 
  array (
    '0d99c9f12fa3acbff4d48e6a8bb2f3147978d28f' => 
    array (
      0 => '/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/popular.tpl',
      1 => 1497451794,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59414d6b23cb41_35298577 ($_smarty_tpl) {
?>

<section class="most-popular py-5">
  <div class="container">
    <div class="row justify-content-center">

      <div class="col-md-8 mb-5">
        <span class="title-one">Most </span>
        <span class="title-two">Popular Videos</span>
      </div>

      <div class="col-md-10">
        <div class="row popularVideos">

        <?php
$_from = $_smarty_tpl->tpl_vars['popularVideos']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_video_0_saved_item = isset($_smarty_tpl->tpl_vars['video']) ? $_smarty_tpl->tpl_vars['video'] : false;
$_smarty_tpl->tpl_vars['video'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['video']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['video']->value) {
$_smarty_tpl->tpl_vars['video']->_loop = true;
$__foreach_video_0_saved_local_item = $_smarty_tpl->tpl_vars['video'];
?>
          <div class="col-md-3 col-6 most-popular-videos py-3" data-url="https://www.youtube.com/watch?v=<?php echo $_smarty_tpl->tpl_vars['video']->value['youtube_id'];?>
">
            <figure>
              <img src="<?php echo $_smarty_tpl->tpl_vars['video']->value['thumbnail'];?>
" alt="">
            </figure>
            <span class="title-video"><?php echo $_smarty_tpl->tpl_vars['video']->value['title'];?>
</span>
          </div>
        <?php
$_smarty_tpl->tpl_vars['video'] = $__foreach_video_0_saved_local_item;
}
if ($__foreach_video_0_saved_item) {
$_smarty_tpl->tpl_vars['video'] = $__foreach_video_0_saved_item;
}
?>

        </div>
      </div>

    </div>
  </div>
</section>
<?php }
}

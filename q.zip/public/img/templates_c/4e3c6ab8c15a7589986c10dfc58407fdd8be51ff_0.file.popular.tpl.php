<?php
/* Smarty version 3.1.29, created on 2017-07-20 21:24:47
  from "/Users/clear/Programing/projects/repeat.bg/templates/popular.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5970f56f03a773_79426931',
  'file_dependency' => 
  array (
    '4e3c6ab8c15a7589986c10dfc58407fdd8be51ff' => 
    array (
      0 => '/Users/clear/Programing/projects/repeat.bg/templates/popular.tpl',
      1 => 1500575084,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5970f56f03a773_79426931 ($_smarty_tpl) {
?>

<section class="container">
  <div class="video-tabs py-4 px-3">
    
    <ul class="nav nav-tabs" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#playlist" role="tab">In Trend</a>
      </li>
      
    </ul>
    
    <div class="tab-content">
      <div class="tab-pane active" id="playlist" role="tabpanel">
        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>
        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

        <article class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/8j9zMok6two/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCQhZSFbngt6a0_LVIBT4CmGHygiw">
          </figure>
          <h3>Miley Cyrus - Malibu (Official Video)</h3>
          <div class="more-info">
                <span class="account">MileyCyrusVEVO</span>
                <span class="up-date">2017-02-07</span>
              </div>
        </article>

      </div>
      <div class="text-center">
        <span class="show_tabs">Show More</span>
        <span class="hide_tabs">Hide This</span>
      </div>
    </div>
    
  </div>
</section><?php }
}

<?php
/* Smarty version 3.1.29, created on 2018-04-24 12:35:59
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/pages/404.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5adefa7f80a8a0_41593242',
  'file_dependency' => 
  array (
    '860621b77084ba05ab9f482e562a16c4bdf55da5' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/pages/404.tpl',
      1 => 1524562528,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
  ),
),false)) {
function content_5adefa7f80a8a0_41593242 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<section class="text-center errorr">
    <span>404</span>
    <h1>Page not found Please go to </h1>
    <div class="text-center">
        <a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
" class="btn btn-download cd-popup-trigger">Home Page</a>
    </div>
</section><?php }
}

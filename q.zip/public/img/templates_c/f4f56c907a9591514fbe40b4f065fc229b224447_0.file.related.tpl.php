<?php
/* Smarty version 3.1.29, created on 2017-07-20 21:31:55
  from "/Users/clear/Programing/projects/repeat.bg/templates/related.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5970f71bd661a8_48770430',
  'file_dependency' => 
  array (
    'f4f56c907a9591514fbe40b4f065fc229b224447' => 
    array (
      0 => '/Users/clear/Programing/projects/repeat.bg/templates/related.tpl',
      1 => 1500575505,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5970f71bd661a8_48770430 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_truncate')) require_once '/Users/clear/Programing/projects/_framework/libs/smarty/plugins/modifier.truncate.php';
if (!is_callable('smarty_modifier_date_format')) require_once '/Users/clear/Programing/projects/_framework/libs/smarty/plugins/modifier.date_format.php';
if ($_smarty_tpl->tpl_vars['related']->value) {?>
<div class="playlist-box">
	<h2>
		<img src="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['img'];?>
/logo-icon.png" alt="">
		Related Repeats
	</h2>

	<ul id="watch-related" data-count="<?php echo count($_smarty_tpl->tpl_vars['related']->value);?>
" class="video-list">
		<?php
$_from = $_smarty_tpl->tpl_vars['related']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_video_0_saved_item = isset($_smarty_tpl->tpl_vars['video']) ? $_smarty_tpl->tpl_vars['video'] : false;
$_smarty_tpl->tpl_vars['video'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['video']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['video']->value) {
$_smarty_tpl->tpl_vars['video']->_loop = true;
$__foreach_video_0_saved_local_item = $_smarty_tpl->tpl_vars['video'];
?>
		<li class="video-list-item">      
			<div class="thumb-wrapper">
				<a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/watch/<?php echo $_smarty_tpl->tpl_vars['video']->value['id'];?>
" class="thumb-link"><img aria-hidden="true" alt="" style="top: 0px" src="https://i.ytimg.com/vi/<?php echo $_smarty_tpl->tpl_vars['video']->value['id'];?>
/mqdefault.jpg" width="168" height="94">
				</a>
			</div>

			<div class="content-wrapper">
				<a href="/watch?v=8j9zMok6two" class="content-link" title="<?php echo $_smarty_tpl->tpl_vars['video']->value['title'];?>
">
					<h3 class="title"><?php echo smarty_modifier_truncate($_smarty_tpl->tpl_vars['video']->value['title'],40);?>
</h3>
					<div class="more-info">
						<span class="account"><?php echo smarty_modifier_truncate($_smarty_tpl->tpl_vars['video']->value['uploader'],10);?>
</span>
						<span class="up-date"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['video']->value['upload_date']);?>
</span>
					</div>
				</a>
			</div>     
		</li>
		<?php
$_smarty_tpl->tpl_vars['video'] = $__foreach_video_0_saved_local_item;
}
if ($__foreach_video_0_saved_item) {
$_smarty_tpl->tpl_vars['video'] = $__foreach_video_0_saved_item;
}
?>

	</ul>
</div>
<?php }
}
}

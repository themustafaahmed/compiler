<?php
/* Smarty version 3.1.29, created on 2017-06-14 08:06:56
  from "/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/home.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5940c470aeb7a1_98120671',
  'file_dependency' => 
  array (
    '61192b5c45c5f4f2f3ac537dd38c1a0902ec32a5' => 
    array (
      0 => '/var/wwwprefix/projects/youtubemp3.eurocoders.com/templates/home.tpl',
      1 => 1497416728,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:popular.tpl' => 1,
    'file:pages/about_page.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5940c470aeb7a1_98120671 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:popular.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:pages/about_page.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

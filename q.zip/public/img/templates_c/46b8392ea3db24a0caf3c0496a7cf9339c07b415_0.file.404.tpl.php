<?php
/* Smarty version 3.1.29, created on 2017-07-19 19:52:33
  from "/Users/clear/Programing/projects/repeat.bg/templates/pages/404.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_596f8e51c34399_37116560',
  'file_dependency' => 
  array (
    '46b8392ea3db24a0caf3c0496a7cf9339c07b415' => 
    array (
      0 => '/Users/clear/Programing/projects/repeat.bg/templates/pages/404.tpl',
      1 => 1497523140,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_596f8e51c34399_37116560 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<section class="container main">
  <div class="row py-5 justify-content-center">
    <div class="col-md-10">
      <div class="row">

        <div class="col-md-5">
          <span class="about-us pl-2">About<small>us</small></span>
        </div>

        <div class="col-md-7">
          <p>  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      
            <p>It has survived not only five centuries, but also the leap into electronic typesetting.</p>
            <a href="#">mail@to.me</a>
        </div>

      </div>

      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p>

    </div>
  </div>
</section>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

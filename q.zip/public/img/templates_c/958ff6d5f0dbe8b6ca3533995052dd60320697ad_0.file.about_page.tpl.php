<?php
/* Smarty version 3.1.29, created on 2017-07-19 19:46:55
  from "/Users/clear/Programing/projects/repeat.bg/templates/pages/about_page.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_596f8cffbeba01_40492969',
  'file_dependency' => 
  array (
    '958ff6d5f0dbe8b6ca3533995052dd60320697ad' => 
    array (
      0 => '/Users/clear/Programing/projects/repeat.bg/templates/pages/about_page.tpl',
      1 => 1497523140,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_596f8cffbeba01_40492969 ($_smarty_tpl) {
?>
<section class="container main">
  <div class="row py-5 justify-content-center">
    <div class="col-md-10">
      <div class="row">

        <div class="col-md-5">
          <span class="about-us pl-2">About<small>us</small></span>
        </div>

        <div class="col-md-7">
          <p>  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      
            <p>It has survived not only five centuries, but also the leap into electronic typesetting.</p>
        </div>

      </div>

      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting,   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
      <p>It has survived not only five centuries, but also the leap into electronic typesetting, </p>

    </div>
  </div>
</section>
<?php }
}

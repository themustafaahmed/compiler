
var ytplayer;

var videoConfig = {
	id    : getParam('v') ? getParam('v') : "QnYsgCUPNRc",
	start : 0,
	end   : -1,
	volume: 1.0
};

// videoConfig.start = 550;
// videoConfig.end = 580;

// console.log(getParam('start'));

videoConfig.start = getParam('start') ? parseInt(getParam('start')) : 550;
videoConfig.end = getParam('end') ? parseInt(getParam('end')) : 580;

// videoConfig.end = 625;	
// videoConfig.end = 580;	

function getParam(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}

function onYouTubePlayerAPIReady() {
		ytplayer = new YT.Player('player', {
		height: '430px',
		width: '100%',
		videoId: videoConfig.id,
		playerVars: {
		  'autoplay': 0,
		  'controls': 1,
		  'html5'   : 1,
		  'enablejsapi':0,
		  'color'   : 'white',
		  'theme'   : 'light'
		},
		events: {
		'onReady': onPlayerReady,
		'onStateChange': onPlayerStateChange}
		});

}

function onPlayerReady(event) {
	if(videoConfig.start){
		repeat(videoConfig.start, videoConfig.end);
	}
}

function onPlayerStateChange(event) {

}

function stopVideo() {

}

function repeat(start, end){

		// ytplayer.pauseVideo();

      	if (typeof(setinterval) != 'undefined') {
			clearInterval(setinterval);
		}

      	this.start = start;
		this.end = end;
		this.duration = parseInt(this.end) - parseInt(this.start);

		if (this.end > ytplayer.getDuration()) {
			alert('The end time must be within the video length.');
			return;
		}

		if (this.duration < 1) {
			alert('Only a more than 1 second loop duration is allowed.');
			return;
		}

		this.seekTo = function(){
			if (ytplayer) {
				ytplayer.seekTo(this.start, true);
				this.timer();
			}
		}

		this.updateTime = function(){

			if (this.end < ytplayer.getCurrentTime()) {
				// ytplayer.pauseVideo();
				clearInterval(setinterval);
				// ytplayer.pauseVideo();
				this.seekTo();
				// ytplayer.playVideo();
			}
		}

		this.timer = function(){
			setinterval = setInterval('this.updateTime()', 100);
		}

		this.seekTo();

      }

function replaceQueryParam(param, newval, search) {
    var regex = new RegExp("([?;&])" + param + "[^&;]*[;&]?");
    var query = search.replace(regex, "$1").replace(/&$/, '');

    return (query.length > 2 ? query + "&" : "?") + (newval ? param + "=" + newval : '');
}

(function($){
    $(window).on("load",function(){
        $("#watch-related").mCustomScrollbar({
			setHeight:370,
			theme:"dark-3"
		});
    });
})(jQuery);

$(document).ready(function() {

	//Description
    $("span.show_text").click(function() {
	     $(this).hide();
	     $("span.hide_text").css("display","block");
	     $("div#watch-description-clip").css("height","auto");
	});
	$("span.hide_text").click(function() {
	     $(this).hide();
	     $("span.show_text").show();
	     $("div#watch-description-clip").css("height","278");
	});

	//More videos
    $("span.show_videos").click(function() {
	     $(this).hide();
	     $("span.hide_videos").css("display","block");
	     $(".video-list").css("height","auto");
	});
	$("span.hide_videos").click(function() {
	     $(this).hide();
	     $("span.show_videos").show();
	     $(".video-list").css("height","450");
	});

	$('.last-video-slider').owlCarousel({
	    loop: true,
	    margin: 52,
	    responsiveClass: true,
	    responsive: {
	        0:{
	            items: 1,
	            margin: 35,
	            nav: true
	        },
	        580:{
	            items: 2,
	            margin: 35,
	            nav: true
	        },
	        767:{
	            items: 3,
	            margin: 10,
	            nav: false
	        },
	        992:{
	            items: 4,
	            nav:true,
	            margin: 10,
	            loop: false
	        },
	        1200:{
	            items:4,
	            nav:true,
	            margin: 10,
	            loop: false
	        }
	    }
	});

	//Video tabs
    $("span.show_tabs").click(function() {
	     $(this).hide();
	     $("span.hide_tabs").css("display","block");
	     $(".tab-pane").css("height","auto");
	});
	$("span.hide_tabs").click(function() {
	     $(this).hide();
	     $("span.show_tabs").show();
	     $(".tab-pane").css("height","330");
	});

	var totalSecond = 700;

	//Range
	$("#range").ionRangeSlider({
		type: "double",
		min: 0,
		from: videoConfig.start,
		to: videoConfig.end,
	    max: totalSecond,
	    step: 1,
	    prettify: function (n) {
	    	var timer = secondsToTime(n);
	    	var str = '';

			if(totalSecond >= 60*60){
				str += timer.h+':';
			}

			str += timer.m+':';

			str += timer.s;
    		return str;
	    },
	    onStart: function (data) {
        	console.log("onStart");
	    },
	    onChange: function (data) {

	    	// BUFFERING
	    	// CUED
	    	// ENDED
	    	// PAUSED
	    	// PLAYING
	    	// UNSTARTED
	    	if(YT.PlayerState.PLAYING){
	    		ytplayer.pauseVideo();
	    	}
	        // console.log("onChange");
	    },
	    onFinish: function (data) {

	    	if (ytplayer) {
	    		ytplayer.pauseVideo();

	    // 		var str = window.location.search
				 // str = replaceQueryParam('start', data.from, str)
				 // str = replaceQueryParam('end', data.to, str)
				 // window.location = window.location.pathname + str;

	    		repeat(data.from, data.to);
				// ytplayer.seekTo(data.from, true);
				// this.timer();
			}
	        console.log("onFinish");
	    },
	    onUpdate: function (data) {
	        console.log("onUpdate");
	    }
	});

	function secondsToTime(secs){
		
	    secs = Math.round(secs);
	    var hours = Math.floor(secs / (60 * 60));

	    var divisor_for_minutes = secs % (60 * 60);
	    var minutes = Math.floor(divisor_for_minutes / 60);

	    var divisor_for_seconds = divisor_for_minutes % 60;
	    var seconds = Math.ceil(divisor_for_seconds);

	    return {
	        "h": hours > 9 ? hours : '0'+hours,
	        "m": minutes > 9 ? minutes : '0'+minutes,
	        "s": seconds > 9 ? seconds : '0'+seconds
	    };
	}
});


// Player Settings
var videoConfig = {
	id    : videoID,
	start : 0,
	end   : -1,
	volume: 1.0
};

var countLoops = 0;

var debug = false;
var seekSet = false;

// Update the start and end time if set
videoConfig.start = getParam('start') ? parseInt(getParam('start')) : 0;

// Youtube player Holder
var ytplayer;

// Loop Class Holder
var loopHolder = new loopClass();
loopHolder.start = 0;
// Slider holder
var $range1 = $("#range");

// Youtube Api
// onYouTubePlayerAPIReady
function onYouTubePlayerAPIReady() {
		ytplayer = new YT.Player('player', {
		height: '430px',
		width: '100%',
		videoId: videoConfig.id,
		playerVars: {
		  'autoplay': 0,
		  'controls': 1,
		  'html5'   : 1,
		  'enablejsapi':0,
		  'color'   : 'white',
		  'theme'   : 'light'
		},
		events: {
		'onReady': onPlayerReady,
		'onStateChange': onPlayerStateChange}
		});

}

// onPlayerReady
function onPlayerReady(event) {

	videoConfig.end = getParam('end') ? parseInt(getParam('end')) : videoDuration;

	creatSlider($range1);
	
	loopHolder.repeat(videoConfig.start, videoConfig.end);

	// if(videoConfig.start == 0){
		ytplayer.playVideo();
	// }
}

// onPlayerStateChange
function onPlayerStateChange(event) {
	/** Yourube API
                        -1 (unstarted)
                        0 (ended)
                        1 (playing)
                        2 (paused)
                        3 (buffering)
                        5 (video cued)
                 **/
    if(seekSet === false){
		if (event.data == 0) {
			loopHolder.repeat(videoConfig.start, videoConfig.end);
		}
	} else {
		if (event.data == 0) {
			console.log('test for bug');
			loopHolder.repeat(videoConfig.start, videoConfig.end);
		}
	}
}

// Creat Slider
function creatSlider(element, duplicate){

	var totalSecond = parseInt(ytplayer.getDuration());
	//Range
	element.ionRangeSlider({
		type: "double",
		min: 0,
		from: videoConfig.start,
		to: videoConfig.end <= totalSecond ? videoConfig.end : totalSecond,
	    max: totalSecond,
	    step: 1,
	    min_interval: 3,
	    prettify: function (n) {
	    	var timer = secondsToTime(n);

			if(totalSecond >= 3600){
				return timer.h+':'+timer.m+':'+timer.s;
			} else {
				return timer.m+':'+timer.s;
			}

	    },
	    onStart: function (data) {
        	console.log("onStart");
	    },
	    onChange: function (data) {

	    	// BUFFERING
	    	// CUED
	    	// ENDED
	    	// PAUSED
	    	// PLAYING
	    	// UNSTARTED
	    	if(YT.PlayerState.PLAYING){
	    		if(loopHolder.start != data.from){
	    			ytplayer.pauseVideo();
	    		}
	    	}
	    	if(debug){
	       		console.log("onChange");
	    	}
	    },
	    onFinish: function (data) {

	    	if (ytplayer) {

	    		// console.log(loopHolder.start);
	    		// console.log(data.from);
	    		if(loopHolder.start != data.from){
	    			console.log('pauseed');
	    			ytplayer.pauseVideo();
	    		}

				if (history.pushState){
					history.pushState({}, null, '?start='+data.from+'&end='+data.to);
				} else {
					// var str = window.location.search
					// str = replaceQueryParam('start', data.from, str)
					// str = replaceQueryParam('end', data.to, str)
					// window.location = window.location.pathname + str;
				}

				videoConfig.start = data.from;
				videoConfig.end = data.to;

				loopHolder.repeat(data.from, data.to);

				// duplicate.data('ionRangeSlider').update({
    //         		to: data.to,
    //         		from: data.from
    //     		});


        		if(YT.PlayerState.PAUSED){
					ytplayer.playVideo();
        		}
        		
			}
			if(debug){
	        	console.log("onFinish");
	    	}
	    },
	    onUpdate: function (data) {
	    	if(debug){
	        	console.log("onUpdate");
	    	}
	    }
	});
}

// Helpers
function secondsToTime(secs){
		
    secs = Math.round(secs);
    var hours = Math.floor(secs / 3600);

    var divisor_for_minutes = secs % 3600;
    var minutes = Math.floor(divisor_for_minutes / 60);

    var divisor_for_seconds = divisor_for_minutes % 60;
    var seconds = Math.ceil(divisor_for_seconds);

    return {
        "h": hours > 9 ? hours : '0'+hours,
        "m": minutes > 9 ? minutes : '0'+minutes,
        "s": seconds > 9 ? seconds : '0'+seconds
    };
}

function replaceQueryParam(param, newval, search) {
    var regex = new RegExp("([?;&])" + param + "[^&;]*[;&]?");
    var query = search.replace(regex, "$1").replace(/&$/, '');

    return (query.length > 2 ? query + "&" : "?") + (newval ? param + "=" + newval : '');
}

function getParam(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}

// Loop Class
function loopClass(){}

loopClass.prototype.repeat = function(start, end){

  	if (typeof(setinterval) != 'undefined') {
		clearInterval(setinterval);
	}

	if (end > parseInt(ytplayer.getDuration())) {
		end = parseInt(ytplayer.getDuration());
	}

	this.prevStart = this.start;
  	this.start = start;
	this.end = end;
	this.duration = parseInt(this.end) - parseInt(this.start);

	if (this.end > parseInt(ytplayer.getDuration())) {
		alert('The end time must be within the video length.');
		return;
	}

	if (this.duration < 1) {
		alert('Only a more than 1 second loop duration is allowed.');
		return;
	}

	if(this.prevStart != this.start){
		console.log('seekTo: '+this.prevStart+' vs '+this.start);
		this.seekTo();
	} else {
		console.log('timer: '+this.prevStart+' vs '+this.start);
		this.timer();
	}

}

loopClass.prototype.updateTime = function(){

	if (this.end < ytplayer.getCurrentTime()) {
		countLoops += 1;
		$('#countLoops').html(countLoops);
		clearInterval(setinterval);
		this.seekTo();

		if(countLoops == 10){
			$.ajax({
                data: {videoID: videoID, startDuration: this.start, endDuration: this.end},
                type: "POST",
                url: baseURL+'/ajax/duration/',
                dataType: 'json',
                success: function(response){
                }
            });
		}
        ItunesDeals(countLoops);
	}
}

loopClass.prototype.timer = function(){
	setinterval = setInterval('loopHolder.updateTime()', 100);
}

loopClass.prototype.seekTo = function() {
	if (ytplayer) {
		if(seekSet === false){
			seekSet = true
		}
		// console.log('repeat seekTO');
		ytplayer.seekTo(this.start, true);
		this.timer();
		if(YT.PlayerState.PAUSED){
			ytplayer.playVideo();
		}
	}
};

// Marina stuff
(function($){
    $(window).on("load",function(){
        $("#watch-related").mCustomScrollbar({
        	alwaysShowScrollbar: 2,
			setHeight:660,
			// setHeight: parseInt($('#watch-related').attr('data-count') * 88),
			theme:"dark-3"
		});
    });
})(jQuery);

$(document).ready(function() {

	 $(document).on('submit', '#searchForm', function(event) {

            event.preventDefault();
            $.ajax({
                data: $('#searchForm').serialize(),
                type: "POST",
                url: baseURL+'/ajax/fetch/',
                dataType: 'json',
                success: function(response){
                    if(response.success){
                        window.location.href = response.url;
                    } else if(response.error){

                        new Noty({
                            timeout: 5000,
                            progressBar: true,
                            type: 'error',
                            
                            closeWith: ['click', 'button'],
                            text: response.error,
                        }).show();

                    }
                }
            });

        });

	//Description
    $("span.show_text").click(function() {
	     $(this).hide();
	     $("span.hide_text").css("display","block");
	     $("div#watch-description-clip").css("height","auto");
	});
	$("span.hide_text").click(function() {
	     $(this).hide();
	     $("span.show_text").show();
	     $("div#watch-description-clip").css("height","278");
	});

	//More videos
    $("span.show_videos").click(function() {
	     $(this).hide();
	     $("span.hide_videos").css("display","block");
	     $(".video-list").css("height","auto");
	});
	$("span.hide_videos").click(function() {
	     $(this).hide();
	     $("span.show_videos").show();
	     $(".video-list").css("height","450");
	});

	$('.last-video-slider').owlCarousel({
	    loop: true,
	    margin: 52,
	    responsiveClass: true,
	    responsive: {
	        0:{
	            items: 1,
	            margin: 35,
	            nav: true
	        },
	        580:{
	            items: 2,
	            margin: 35,
	            nav: true
	        },
	        767:{
	            items: 3,
	            margin: 10,
	            nav: true
	        },
	        992:{
	            items: 4,
	            nav:true,
	            margin: 10,
	            loop: false
	        },
	        1200:{
	            items:4,
	            nav:true,
	            margin: 10,
	            loop: false
	        }
	    }
	});

    $("span.show_tabs").click(function() {
	     $(this).hide();
	     $("span.hide_tabs").css("display","block");
	     $(".tab-pane").css("height","auto");
	});
	$("span.hide_tabs").click(function() {
	     $(this).hide();
	     $("span.show_tabs").show();
	     $(".tab-pane").css("height","330");
	});

	

	$('body').on('click', '.js-sharer',function(e){
		e.preventDefault();

		var shareUrl = '';
		var service = $(this).attr("data-service").toLowerCase();
		var title = $('.title-left h1').text();
		var id = $(this).attr("data-id");

		var thumb = "https://i.ytimg.com/vi/"+id+"/hqdefault.jpg";

		var mediaUrl = "http://repeat.bg/watch/"+id;

		var description = "Repeat youtube videos automatically at http://repeat.bg";

		var caption = "REPEAT.BG";

		var videoFrom = getParam('start') ? parseInt(getParam('start')) : 0;
		var videoTo = getParam('end') ? parseInt(getParam('end')) : 0;

		if(videoFrom !==0){
			mediaUrl += "&start="+videoFrom;
		}

		if(videoTo !== parseInt(ytplayer.getDuration())){
			mediaUrl += "&end="+videoTo;
		}

		mediaUrl = encodeURIComponent(mediaUrl);

		var fbAppId = 1;
		if(service == 'reddit'){
			 shareUrl = 'http://www.reddit.com/submit?url='+mediaUrl+'&title='+title+' on repeat at http://repeat.bg';
		} else if (service == 'facebook'){
			shareUrl = 'https://www.facebook.com/dialog/feed?app_id='+fbAppId+'&display=popup&description='+description+'&caption='+caption+'&link='+mediaUrl+'&redirect_uri='+mediaUrl+'&picture='+thumb;

		} else if (service == 'twitter'){
			 shareUrl = 'https://twitter.com/share?url='+mediaUrl+'&text='+title+'&via=youtubeonrepeat&hashtags=onrepeat'
		} else if(service == 'google+'){
			shareUrl = 'https://plus.google.com/share?url='+mediaUrl;
		} else if (service == 'pinterest'){
			shareUrl = 'http://pinterest.com/pin/create/button/?url='+mediaUrl+'&description='+title+' on repeat at http://repeat.bg&media='+thumb;
		} else if (service == 'tumblr'){
			shareUrl = 'http://tumblr.com/share/link?url='+mediaUrl+'&content='+thumb+'&posttype=photo&tags=onrepeat,repeat&show-via='+mediaUrl;
		}

        if(shareUrl.length){
        	window.open(shareUrl,"Sharer","height=500,width=900,top=150,left=150").focus();
        }

	});

	//open popup
	$('.cd-popup-trigger').on('click', function(event){

		event.preventDefault();

		var id = $(this).attr('data-id');

		$.ajax({
            data: {videoID: videoID, startDuration: videoConfig.start, endDuration: videoConfig.end},
            type: "POST",
            url: baseURL+'/ajax/encrypt/',
            dataType: 'json',
            success: function(response){
            	$(".encrypt_range").attr('href', 'http://youtubemp3.eurocoders.com/repeat/'+response.url);
            }
        });

		$('.cd-popup.'+id).addClass('is-visible');
	});
	
	//close popup
	$('.cd-popup').on('click', function(event){
		if( $(event.target).is('.cd-popup-close') || $(event.target).is('.cd-popup') ) {
			event.preventDefault();
			$(this).removeClass('is-visible');
		}
	});
	//close popup when clicking the esc keyboard button
	$(document).keyup(function(event){
    	if(event.which == '27'){
    		$('.cd-popup').removeClass('is-visible');
	    }
    });

});

/**
 * Init function ItunesDeals
 * @param loop
 * @constructor
 */

function ItunesDeals(loop) {

	//Call function Interval and var check = returned from Interval function
    var check = Interval(loop);

    // If varible check === 1 and loop not equal on 0 Call function LoadItunesDeals
    if(check === 1 && loop != 0){
        LoadItunesDeals();
	}
};

/**
 * Init function Interval
 * @param size
 * @returns {number}
 * @constructor
 */
function Interval(size) {

	// If size % 10 === 0 retrun 1 else return 0
    return ((size % 10 === 0) ? 1 : 0);
}

/**
 * Init function LoadItunesDeals for popup
 * @constructor
 */
function LoadItunesDeals() {
    var id = $("#itunes_deals").attr('data-id');
    $('.cd-popup.'+id).addClass('is-visible');
}
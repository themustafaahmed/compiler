<?php
//test
// 22642 - 5
// 23691 - 10:15
// 23836 - 6:58

$allow = array('79.98.105.254','213.191.177.85','176.12.18.133','78.130.158.35','185.94.192.147','88.80.159.17','78.130.158.35', '87.126.226.207','83.228.79.117', '87.126.177.13','88.80.159.83','78.130.158.35');
$currentIp = $_SERVER['REMOTE_ADDR'];
if(!in_array($currentIp, $allow)){
	die;
}

// define('ffmpegPath', '/usr/local/bin/ffmpeg');
// define('youtubeDLPath', '/usr/local/bin/youtube-dl');

/**
 * @package		TRP Framework
 * @author		Marian Petrov
 * @version		1.0
 * @copyright	Copyright (c) 2017
 */

// --------------------------------------------------------------
// Tick... Tock... Tick... Tock...
// --------------------------------------------------------------
$time_start = microtime(true);

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('upload_max_filesize', 5000);
ini_set('post_max_size', 5000);
ini_set('file_uploads', 1);

session_start();

// Current IP
$currentIp = $_SERVER['REMOTE_ADDR'];

// --------------------------------------------------------------
// Find the framework path
// --------------------------------------------------------------
$frameworkPath = realpath(dirname(__FILE__). '/..').'/_framework';

include_once($frameworkPath.'/core/Paths.php');
include_once($frameworkPath.'/core/Router.php');
include_once($frameworkPath.'/core/Registry.php');
include_once($frameworkPath.'/core/Database.php');
include_once($frameworkPath.'/core/Loader.php');
include_once($frameworkPath.'/core/BaseController.php');

// --------------------------------------------------------------
// Load settings files
// --------------------------------------------------------------
$siteSettings  = Loader::loadConfig('siteSettings');
$dbSettings    = Loader::loadConfig('dbSettings');
$debugSettings = Loader::loadConfig('debugSettings');

// --------------------------------------------------------------
// Init the Database holder
// --------------------------------------------------------------
$dbh = Database::getInstance($dbSettings);

// --------------------------------------------------------------
// Load & Init the Smarty
// --------------------------------------------------------------
Loader::loadCore('Smarty.class', 'libs', 'smarty');

$smarty = new Smarty;
$smarty->debugging = false;

$smarty->template_dir = path('templates');
$smarty->compile_dir  = path('templates_c');

// --------------------------------------------------------------
// Check if the database debug is on & if $currentIp is dev ip
// --------------------------------------------------------------
if(is_array($debugSettings)){
	if($debugSettings['db_debug'] == true){
		if(in_array($currentIp, $debugSettings['ips'])){
			$dbh->debugger = true;
		}
	}
}

$mem_var = new Memcached();
$mem_var->addServer("127.0.0.1", 11211);

// --------------------------------------------------------------
// Assign settings into smarty
// --------------------------------------------------------------
$smarty->assign('siteSettings', $siteSettings);
$smarty->assign('debugSettings', $debugSettings);
$smarty->assign('timestamp', time());

// --------------------------------------------------------------
// Set settings into the Registry
// --------------------------------------------------------------
Registry::set($debugSettings, 'debugSettings');
Registry::set($siteSettings, 'siteSettings');
Registry::set($smarty, 'smarty');
Registry::set($mem_var, 'memcached');
Registry::set($dbh, 'dbh');

$smarty->assign('currentUrl', Router::currentUri());

// --------------------------------------------------------------
// Let there be light
// --------------------------------------------------------------
Router::run();

// --------------------------------------------------------------
// Print table for debugging SQL queries
// --------------------------------------------------------------
if($dbh->debugger){
	$dbh->showSQLDebugger();
}

// --------------------------------------------------------------
// Tick... Tock... Tick... Tock...
// --------------------------------------------------------------
if($debugSettings['loading_time']){
	$time_end = microtime(true);
}

// --------------------------------------------------------------
// The application load time
// --------------------------------------------------------------
if($debugSettings['loading_time']){
echo '
<!-- Loading time: ' . round($time_end - $time_start, 4) . ' sec --!>';
}

?>

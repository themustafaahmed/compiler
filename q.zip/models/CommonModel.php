<?php


class CommonModel
{
    private $dbh;

    private $memcached;

    public function __construct()
    {
        $this->dbh = Registry::get('dbh');
        $this->memcached = Registry::get('memcached');
    }

    /**
     * Init function convertIntoNumber
     * Converts youtubeID to simple ID
     * @param $youtubeID
     * @return mixed|string
     */
    public function convertIntoNumber($youtubeID)
    {
        // Fetch the cached value
        $number = $this->memcached->get('to_number_' . $youtubeID);

        if (empty($number)) {
            $number = $this->dbh->fetchOne("SELECT video_id FROM videos WHERE youtube_id = :youtube_id", array('youtube_id' => $youtubeID));
            if (empty($number)) {
                if ($this->dbh->insert('videos', array('youtube_id' => $youtubeID))) {
                    $number = $this->dbh->lastInsertId();
                    // Set the cache for this video
                    $this->memcached->set('to_number_' . $youtubeID, $number, 0);
                } else {
                    $number = '';
                }

            } else {
                $this->memcached->set('to_number_' . $youtubeID, $number, 0);
            }
        }

        return $number;
    }

}

?>
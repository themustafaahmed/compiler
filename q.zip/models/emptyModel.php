<?php

class emptyModel {

	private static $dbh;

	public static function init(){
		if(empty(self::$dbh)){
        	self::$dbh = Registry::get('dbh');
    	}
	}
	
	public static function getStuff(){
		self::init();
		self::$dbh->fetchRow('SELECT * FROM root WHERE id=8');
	}

	public static function getMoreStuff(){
		self::init();
		self::$dbh->fetchRow('SELECT * FROM root WHERE id=88');
	}

}

?>
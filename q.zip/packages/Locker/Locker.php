<?php

/**
 * Class Locker
 */
class Locker
{

    public $filename;
    private $_lock;

    /**
     * Locker constructor.
     * @param $filename
     */
    public function __construct($filename)
    {
        $this->filename = dirname(__FILE__) . "/" . $filename;
    }

    /**
     * Locks relevant file
     */
    public function lock()
    {
        $this->_lock = fopen($this->filename, 'w') or die ('Cannot create lock file');
        $result = flock($this->_lock, LOCK_EX | LOCK_NB);
        if ($result == false) {
            die("Already running, shutting down\n");
        }
    }

    /**
     * Unlock above file
     */
    public function unlock()
    {
        flock($this->_lock, LOCK_UN);
    }

}

?>
<?php
/* Smarty version 3.1.29, created on 2018-11-05 12:08:24
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/home.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5be016980164f4_97850766',
  'file_dependency' => 
  array (
    '2eedeeb07b7e5986dc78b6a78f7a8d302faf6868' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/home.tpl',
      1 => 1501587139,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:popular.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5be016980164f4_97850766 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:popular.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

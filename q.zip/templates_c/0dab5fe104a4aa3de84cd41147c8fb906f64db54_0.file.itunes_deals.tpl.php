<?php
/* Smarty version 3.1.29, created on 2018-11-14 12:39:13
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/itunes_deals.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5bebfb516ce899_84871073',
  'file_dependency' => 
  array (
    '0dab5fe104a4aa3de84cd41147c8fb906f64db54' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/itunes_deals.tpl',
      1 => 1542191618,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bebfb516ce899_84871073 ($_smarty_tpl) {
?>


<?php echo $_smarty_tpl->tpl_vars['itunes_deals']->value;
}
}

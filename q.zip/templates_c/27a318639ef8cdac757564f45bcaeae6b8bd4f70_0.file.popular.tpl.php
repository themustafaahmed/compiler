<?php
/* Smarty version 3.1.29, created on 2018-11-07 22:52:25
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/popular.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5be350891a5982_70782417',
  'file_dependency' => 
  array (
    '27a318639ef8cdac757564f45bcaeae6b8bd4f70' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/popular.tpl',
      1 => 1541623943,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5be350891a5982_70782417 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once '/var/wwwprefix/projects/_framework/libs/smarty/plugins/modifier.date_format.php';
?>

<?php if ($_smarty_tpl->tpl_vars['popularVideos']->value) {?>
<section class="container">
  <div class="video-tabs py-4 px-3">
    
    <ul class="nav nav-tabs" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#playlist" role="tab">In Trend</a>
      </li>
      
    </ul>
    
    <div class="tab-content">
      <div class="tab-pane active" id="playlist" role="tabpanel">
      <?php
$_from = $_smarty_tpl->tpl_vars['popularVideos']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_video_0_saved_item = isset($_smarty_tpl->tpl_vars['video']) ? $_smarty_tpl->tpl_vars['video'] : false;
$_smarty_tpl->tpl_vars['video'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['video']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['video']->value) {
$_smarty_tpl->tpl_vars['video']->_loop = true;
$__foreach_video_0_saved_local_item = $_smarty_tpl->tpl_vars['video'];
?>
        <a href="<?php echo $_smarty_tpl->tpl_vars['siteSettings']->value['url'];?>
/watch/<?php echo $_smarty_tpl->tpl_vars['video']->value['youtube_id'];
if ($_smarty_tpl->tpl_vars['video']->value['end']) {?>?start=<?php echo $_smarty_tpl->tpl_vars['video']->value['start'];?>
&end=<?php echo $_smarty_tpl->tpl_vars['video']->value['end'];
}?>" class="last-video-box items">
          <figure>
            <img src="https://i.ytimg.com/vi/<?php echo $_smarty_tpl->tpl_vars['video']->value['youtube_id'];?>
/mqdefault.jpg">
          </figure>
          <span class="h3"><?php echo $_smarty_tpl->tpl_vars['video']->value['title'];?>
</span>
          <div class="more-info">
                <span class="account"><?php echo $_smarty_tpl->tpl_vars['video']->value['uploader'];?>
</span>
                <span class="up-date"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['video']->value['upload_date']);?>
</span>
              </div>
        </a>
        <?php
$_smarty_tpl->tpl_vars['video'] = $__foreach_video_0_saved_local_item;
}
if ($__foreach_video_0_saved_item) {
$_smarty_tpl->tpl_vars['video'] = $__foreach_video_0_saved_item;
}
?>

      </div>
      <div class="text-center">
        <span class="show_tabs">Show More</span>
        <span class="hide_tabs">Show Less</span>
      </div>
    </div>
    
  </div>
</section>
<?php }
}
}

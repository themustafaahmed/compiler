<?php
/* Smarty version 3.1.29, created on 2018-11-07 11:58:47
  from "/var/wwwprefix/projects/repeat.eurocoders.com/templates/pages/contact_page.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5be2b757e13373_57840145',
  'file_dependency' => 
  array (
    'd3a8d20b7f6c6319fba9286ca1414f0421d42930' => 
    array (
      0 => '/var/wwwprefix/projects/repeat.eurocoders.com/templates/pages/contact_page.tpl',
      1 => 1524564279,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5be2b757e13373_57840145 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<section class="container main py-4">
    
    <h1 class="text-center">Contact us</h1>
    <p>  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
    
    <p>It has survived not only five centuries, but also the leap into electronic typesetting.</p>
    <a href="#">mail@to.me</a>

</section>
<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

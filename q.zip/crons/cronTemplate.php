<?php

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);

include 'cronConfig.php';

// $dbh->fetchAll("Type your sql query here");
print_r($dbSettings);

?>
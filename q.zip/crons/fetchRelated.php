<?php

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);

include 'cronConfig.php';
Loader::loadPackages('Locker');
include_once($frameworkPath.'/core/Registry.php');
/**
 * Class GetRelated
 */
class GetRelated
{
    // Database holder
    protected $dbh;

    // Memcached holder
    protected $memcached;

    // Youtube Api Key holder
    protected $apiKey;

    // Youtube Fetch holder
    protected $youtubeFetch;

    private $model;

    /**
     * GetRelated constructor.
     * @param $dbh
     * @param $siteSettings
     */
    function __construct($dbh, $siteSettings,$model)
    {
        // Set the Memcached holder
        $this->memcached = new Memcached();

        // Configuration memcached server
        $this->memcached->addServer("127.0.0.1", 11211);

        //$dbh->inlineDebug = true;
        // Database holder
        $this->dbh = $dbh;

        // Youtube fetch Api Key holder
        $this->apiKey = $siteSettings['youtubeApiKeys'];

        // Youtube Fetch Holder
        $this->youtubeFetch = new Core\Packages\YoutubeFetch();

        $this->model = $model;
    }

    /**
     * Init function RelatedVideos
     * @param array $video_ids
     * @return bool
     */
    public function RelatedVideos(array $video_ids)
    {

        // Fetch the API keys
        $youtubeApiKeys = $this->apiKey;

        // Select a random key
        $apiKey = $youtubeApiKeys[rand(0, count($youtubeApiKeys) - 1)];

        $printer = 0;

        foreach ($video_ids as $video_id) {

            // Print video number and colorized terminal for easy check
            $printer++;
            echo "\033[33m" . "Video number: " . $printer . "\033[0m" . "\n";

            // Try to get the video related videos from cache or database
            $relatedVideos = $this->getVideoRelated($video_id['video_id']);

            // If we don't have any data..
            if (empty($relatedVideos)) {

                //echo $video_id['youtube_id'];
                // Fetch it from the API
                $related = $this->youtubeFetch->getRelatedToVideoIDApi($video_id['youtube_id'], $apiKey, true);

                $printer_related = 0;

                // Loop throught the API result
                foreach ($related as $_related) {
                    $_video_id = $this->convertIntoNumber($_related['id']);
                   // $_video_id = $this->model->convertIntoNumber($_related['id']);
                    if (empty($_video_id)) {
                        die('Error: Num 2');
                    }

                    $printer_related++;
                    echo "\033[36m" . "Related video number: " . $printer_related . "\033[0m" . "\n";

                    // Try to get the video from cache or database
                    $check = $this->getVideo($_video_id);

                    // If the video is new
                    if (empty($check)) {
                        if (!isset($check['video_id'])) {
                            $check['video_id'] = $_video_id;
                        }

                        // Fetch additional information
                        $item = $this->youtubeFetch->getVideoInfoApi($_related['id'], $apiKey, false);
                        // $this->PrintArray($item);
                       //print_r($item);
                        // Check if the video is `processed` and `public`
                        if ($item['uploadStatus'] == 'processed' && $item['privacyStatus'] == 'public') {

                            // Prepate the insert array
                            $insertRelatedArray = array(
                                'start' => 0,
                                'end' => 0,
                                'views' => 0,
                                'uploaderAvatar' => $item['uploaderAvatar'],
                                'duration' => $item['duration'],
                                'youtube_id' => $item['id'],
                                'title' => $item['title'],
                                'status' => 'active',
                                'uploader' => $item['uploader'],
                                'upload_date' => $item['upload_date'],
                                'have_related' => '0'
                            );

                            // Try to insert the video
                            // Check if the insertion is successful
                            if ($this->dbh->update("videos", $insertRelatedArray, 'video_id=' . $_video_id)) {

                                echo "Update Videos\n";
                                // Check if the record already exist in cache or database
                                if (empty($this->checkIfRelatedExist($video_id['video_id'], $_video_id, 86400))) {

                                    // Try to insert into related
                                    // Check if the insertion is successful
                                    if ($this->dbh->insert('related', array('video_parent' => $video_id['video_id'], 'video_id' => $_video_id))) {
                                        echo "Insert Related\n";

                                        // Added to the final array holder
                                        $relatedVideos[] = $insertRelatedArray;
                                    }
                                } else {
                                    // echo 'not insert into related!!';
                                    // Added to the final array holder
                                    $relatedVideos[] = $insertRelatedArray;
                                }

                                // Set the cache for this video
                                $this->memcached->set('video_' . $_video_id, $insertRelatedArray, 86400);
                            }
                            sleep(1);
                        }

                    } else {
                        if (!isset($check['video_id'])) {
                            $check['video_id'] = $_video_id;
                        }

                        // Check if the record already exist in cache or database
                        if (empty($this->checkIfRelatedExist($video_id['video_id'], $check['video_id'], 86400))) {

                            if ($this->dbh->insert('related', array('video_parent' => $video_id['video_id'], 'video_id' => $check['video_id']))) {
                                echo "Insert Related Only\n";
                                // Added to the final array holder
                                $relatedVideos[] = $check;
                            }
                        } else {
                            // Added to the final array holder
                            $relatedVideos[] = $insertRelatedArray;
                        }

                    }
                }

                // Check the the array is not empty
                if (!empty($relatedVideos)) {
                    // Set the cache for the video
                    $this->memcached->set('related_' . $video_id['video_id'], $relatedVideos, 86400);
                }
                $update_have_related = $this->dbh->update("videos", array('have_related' => '1'), 'video_id=' . $video_id['video_id']);
                if ($update_have_related) {
                    echo "\033[35m" . "Update have_related Video ID = " . $video_id['video_id'] . "\e[0m\n";
                }
            }
        }
        return true;
    }

    /**
     * Init function getVideoRelated
     * @param $videoID
     * @param int $time
     * @return mixed|string
     */
    protected function getVideoRelated($videoID, $time = 86400)
    {
        // Fetch the cached value
        $relatedVideosInfo = $this->memcached->get('related_' . $videoID);

        // Check if it's empty
        if (empty($relatedVideosInfo)) {

            // Fetch the video information from the database
            $relatedVideos = $this->dbh->column("SELECT video_id FROM related WHERE video_parent = :video_parent", array('video_parent' => $videoID));

            // Check if the video holder is empty
            if (empty($relatedVideos)) {
                return '';
            }

            $ids = "'" . implode("','", $relatedVideos) . "'";
            $relatedVideosInfo = $this->dbh->fetchAll("SELECT * FROM videos WHERE status='active' AND video_id IN($ids)");

            // Set the cache for this video
            $this->memcached->set('related_' . $videoID, $relatedVideosInfo, $time);
        }

        // Return the video information
        return $relatedVideosInfo;
    }

    /**
     * Init function convertIntoNumber
     * Converts youtubeID to simple ID
     * @param $youtubeID
     * @return mixed|string
     */
    private function convertIntoNumber($youtubeID)
    {
        // Fetch the cached value
        $number = $this->memcached->get('to_number_' . $youtubeID);
        if (empty($number)) {
            $number = $this->dbh->fetchOne("SELECT video_id FROM videos WHERE youtube_id = :youtube_id", array('youtube_id' => $youtubeID));
            if (empty($number)) {
                if ($this->dbh->insert('videos', array('youtube_id' => $youtubeID))) {
                    $number = $this->dbh->lastInsertId();
                    // Set the cache for this video
                    $this->memcached->set('to_number_' . $youtubeID, $number, 0);
                } else {
                    $number = '';
                }

            } else {
                $this->memcached->set('to_number_' . $youtubeID, $number, 0);
            }
        }

        return $number;
    }

    /**
     * Init function checkIfRelatedExist
     * @param $videoID
     * @param $youtubeID
     * @param int $time
     * @return mixed|string
     */
    private function checkIfRelatedExist($videoID, $youtubeID, $time = 86400)
    {

        // Fetch the cached value
        $relatedExist = $this->memcached->get('related_' . $videoID . '_' . $youtubeID);
        // Check if it's empty
        if (empty($relatedVideosInfo)) {
            // Fetch the video information from the database
            $relatedExist = $this->dbh->fetchOne("SELECT video_id FROM related WHERE video_parent = :video_parent AND video_id = :video_id", array('video_parent' => $videoID, 'video_id' => $youtubeID));
            if (empty($relatedExist)) {
                return '';
            }

            // Set the cache for this video
            $this->memcached->set('related_' . $videoID . '_' . $youtubeID, true, $time);
        }

        return $relatedExist;
    }

    /**
     * Init function getVideo
     * Trys to fetch the video information from cache or database
     * @param $video_id
     * @param int $time
     * @return mixed|string
     */
    private function getVideo($video_id, $time = 86400)
    {
        // Fetch the cached value
        $videoInfo = $this->memcached->get('video_' . $video_id);

        // Check if it's empty
        if (empty($videoInfo)) {

            // Fetch the video information from the database
            $videoInfo = $this->dbh->fetchRow("SELECT * FROM videos WHERE status = 'active' AND video_id = '" . $video_id . "'");

            // Check if the video holder is empty
            if (empty($videoInfo)) {
                return '';
            }

            // Set the cache for this video
            $this->memcached->set('video_' . $video_id, $videoInfo, $time);
        }

        // Return the video information
        return $videoInfo;
    }

    /**
     * Init function PrintArray
     * Print beautiful array
     * @param $array
     */
    protected function PrintArray($array)
    {
        echo "<pre>" . print_r($array, true) . "</pre>";
    }

}

$locker = new Locker('fetchRelated.lock');

// Lock Cron
$locker->lock();

// Load siteSettings Class
$siteSettings = Loader::loadConfig('siteSettings');

//Load Model
$model = Loader::LoadModel('Common');
// Init GetRelated Class
$getRelated = new GetRelated($dbh, $siteSettings,$model);

// Fetch videos in Db
$videos = $dbh->fetchAll("SELECT video_id,youtube_id FROM videos WHERE have_related = '0' LIMIT 1000");  // . $param5000, 1000

// Call function RelatedVideos
$check = $getRelated->RelatedVideos($videos);

// Check
if ($check) {

    // Unlock Cron
    echo "Done\n";
    $locker->unlock();
}

?>
<?php

// $data = file_get_contents('/var/wwwprefix/projects/youtubemp3.eurocoders.com/crons/start.txt');
// if(!empty($data)){
// 	die;
// }
file_put_contents('/var/wwwprefix/projects/youtubemp3.eurocoders.com/crons/start.txt', 'update from cron 6 - 24479');

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);

include 'cronConfig.php';



Loader::loadPackages('youtubeFetch');

$youtubeFetch = new YoutubeFetch();

$playlistsLog = file_get_contents('/var/wwwprefix/projects/youtubemp3.eurocoders.com/crons/log/youtubeFetch_playlists.txt');
$playlists = explode(',', $playlistsLog);
foreach ($playlists as $playlist) {


	preg_match('/list=(.*?)$/is', $playlist, $match);
	if(!empty($match[1])){
		$playlistId = $match[1]; 
		$playlistVideos = $youtubeFetch->fetchPlaylistVideos($playlist);

		foreach ($playlistVideos as $videoID) {
            $exist = $dbh->fetchOne('SELECT id FROM videos WHERE youtube_id = :youtube_id', array('youtube_id' => $videoID));
//            $exist  = $this->memcached->get("exist".$videoID);
//            if(!$exist){
//                $_exist = $dbh->fetchOne('SELECT id FROM videos WHERE youtube_id = :youtube_id', array('youtube_id' => $videoID));
//                $this->memcached->set("exist".$videoID,$_exist,60);
//                $exist = $this->memcached->get("exist".$videoID);
//            }

			if(empty($exist)){

				// $youtubeFetch->execDebug = true;
				$videoInfo = $youtubeFetch->fetchVideoInfoCustom($videoID, array('title', 'thumbnail'));
				
				if(is_array($videoInfo) && !empty($videoInfo)){
					if(!empty($videoInfo[0])){

						if (strstr($videoInfo[0], 'ERROR: ') === false) {

							$insertArray = array(
								'thumbnail'        => $videoInfo[1],
								'title'            => $videoInfo[0],
								'youtube_id'       => $videoID
							);

							$dbh->insert('videos', $insertArray);
							
						} else {

							$insertArray = array(
								'parse_error'       => '1',
								'youtube_id'       => $videoID
							);

							$dbh->insert('videos', $insertArray);

						}
					}
				}
			}
		}
	}
}


?>
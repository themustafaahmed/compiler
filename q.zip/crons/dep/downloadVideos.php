<?php

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);

include 'cronConfig.php';

Loader::loadPackages('YoutubeFetch');

$youtubeFetch = new YoutubeFetch();
$youtubeFetch->fetchChannelPlaylist(1);

$videos = $dbh->fetchAll("SELECT * FROM videos WHERE is_converted = '0'");

foreach ($videos as $videoID) {

	$converted = $youtubeFetch->downloadAndConvertVideo($videoID['youtube_id']);
	if($converted){
		$dbh->update('videos', array('is_converted' => '1'), "id = '".$videoID['id']."'");
		// update OK
	} else {
		$dbh->update('videos', array('failed_convert' => '1'), "id = '".$videoID['id']."'");
		// update FAIL
	}
		

}

?>
<?php

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);

include 'cronConfig.php';


Loader::loadPackages('YoutubeFetch');

$youtubeFetch = new YoutubeFetch();
$youtubeFetch->debug = true;

// oEc_7qjaSFg
$videoID = $argv[1];
if(empty($videoID)){
	die(PHP_EOL.'###Please add a video ID!###'.PHP_EOL);
}

if(strlen($videoID) < 11){
	die(PHP_EOL.'###The video ID length should be 11 char###'.PHP_EOL);
}

	// check if the video is new
	$exist = $dbh->fetchRow("SELECT id FROM videos WHERE youtube_id = '".$videoID."'");
	if(empty($exist)){

		$videoInfo = $youtubeFetch->fetchVideoInfo($videoID);
		if(is_array($videoInfo)){
			$insertArray = array(
				'thumbnail' => $videoInfo['thumbnail'],
				'title' => $videoInfo['title'],
				'youtube_id' => $videoInfo['id'],
				'duration' => $videoInfo['human_duration'],
				'seconds_duration' => $videoInfo['duration'],
				'description' => $videoInfo['description'],
			);
			$dbh->insert('videos', $insertArray);
			$converted = $youtubeFetch->downloadAndConvertVideo($videoID);
			if($converted){
				$dbh->update('videos', array('is_converted' => '1'), "youtube_id = '".$videoInfo['id']."'");
				// update OK
			} else {
				// update FAIL
				$dbh->update('videos', array('failed_convert' => '1'), "youtube_id = '".$videoInfo['id']."'");
			}
		}
		
	}


?>
<?php


$playlists = array(
    //'RDSwL9vOBxeXY',
    //'RDkJQP7kiw5Fk',
    'PLFgquLnL59alCl_2TQvOiD5Vgm1hCaGSI'
);

/*$data = file_get_contents('/var/wwwprefix/projects/youtubemp3.eurocoders.com/crons/start_vevo.txt');
if (!empty($data)) {
    die;
}
file_put_contents('/var/wwwprefix/projects/youtubemp3.eurocoders.com/crons/start_vevo.txt', 'update from cron');*/

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);

include 'cronConfig.php';

$memcached = new Memcached();
$memcached->addServer("127.0.0.1", 11211);

// Load the YoutubeFetch package
$youtubeFetch = new Core\Packages\YoutubeFetch();

foreach ($playlists as $playlist) {
    //$cache = $memcached->get("_play");
      //  $result = $youtubeFetch->fetchPlaylistVideos($playlist);

    foreach ($youtubeFetch->videoIDs as $videoID) {
        print_r($videoID);
        die;
        // check if the video is new
        $exist = $dbh->fetchRow("SELECT id FROM videos WHERE youtube_id = '" . $videoID . "'");

        if (empty($exist)) {
            $videoInfo = $youtubeFetch->fetchVideoInfo($videoID);
            if (is_array($videoInfo) && !empty($videoInfo)) {
                if (!empty($videoInfo['id'])) {
                    $insertArray = array(
                        'thumbnail' => $videoInfo['thumbnail'],
                        'title' => $videoInfo['title'],
                        'youtube_id' => $videoInfo['id'],
                        'duration' => $videoInfo['human_duration'],
                        'seconds_duration' => $videoInfo['duration'],
                        'description' => $videoInfo['description'],
                    );
                    $insert = $dbh->insert('videos', $insertArray);
                    if ($insert) {
                        echo "ok";
                    } else {
                        echo "err";
                    }
                    sleep(3);
                }
            }

        }

    }
}

?>
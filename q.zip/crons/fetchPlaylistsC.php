<?php

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);

include 'cronConfig.php';

/**
 * Class PlayList
 */
class PlayList
{

    // Youtube Fetch holder
    protected $youtubeFetch;

    // Memcached holder
    protected $memcached;

    // Database holder
    protected $dbh;

    // Youtube Api Key holder
    protected $apiKey;

    /**
     * PlayList constructor.
     * @param $dbh
     * @param $siteSettings
     */
    function __construct($dbh, $siteSettings)
    {
        // Youtube Fetch Holder
        $this->youtubeFetch = new Core\Packages\YoutubeFetch();

        // Set the Memchaged holder
        $this->memcached = new Memcached();

        // Configuration memcached server
        $this->memcached->addServer("127.0.0.1", 11211);

        // Database holder
        $this->dbh = $dbh;

        // Youtube fetch Api Key holder
        $this->apiKey = $siteSettings['youtubeApiKeys'];
    }

    /**
     * Init function getPlayList
     * @param $playlists
     */
    public function getPlayLists($playlists)
    {
        // Fetch the API keys
        $youtubeApiKeys = $this->apiKey;

        // Select a random key
        $apiKey = $youtubeApiKeys[rand(0, count($youtubeApiKeys) - 1)];

        return $this->youtubeFetch->fetchChannelPlaylists('UC-9-kyTW8ZkZNDHQJ6FgpwQ');
    }

    /**
     * Init function printArray
     * @param $array
     */
    public function printArray($array)
    {
        echo "<pre>" . print_r($array, true) . "</pre>";
    }
}

// Playlist array
$playlists = array(
    'PLFgquLnL59alCl_2TQvOiD5Vgm1hCaGSI',
    'PLFgquLnL59akA2PflFpeQG9L01VFg90wS',
    'PLLMA7Sh3JsOQQFAtj1no-_keicrqjEZDm',
    'PLUg_BxrbJNY5gHrKsCsyon6vgJhxs72AH',
    'PLS_oEMUyvA728OZPmF9WPKjsGtfC75LiN',
    'PLTDluH66q5mpm-Bsq3GlwjMOHITt2bwXE',
    'PLDcnymzs18LU4Kexrs91TVdfnplU3I5zs',
    'PLx0sYbCqOb8TBPRdmBHs5Iftvv9TPboYG',
    'PLMC9KNkIncKvYin_USF1qoJQnIyMAfRxl',
    'PLMC9KNkIncKtPzgY-5rmhvj7fax8fdxoj',
    'PLMC9KNkIncKtsacKpgMb0CVq43W80FKvo',
    'PL3oW2tjiIxvS6xXdDQ5oJ-0UZWgtA-J5W'
);

// Load siteSettings Class
$siteSettings = Loader::loadConfig('siteSettings');

// Init PlayList class
$list = new PlayList($dbh, $siteSettings);

// Call function getPlayList
$lists = $list->getPlayLists($playlists);

$list->printArray($lists);
?>
<?php

// Include the cronjob config file
include 'cronConfig.php';

// Load the cURL package
Loader::loadCore('cURL', 'package');

// Load the LookUp package
Loader::loadCore('LookUp', 'package');

// Load the Locker package
Loader::loadPackages('Locker');

/**
 * Class Search
 */
class Search
{

    // Database holder
    private $dbh = null;

    // Memcached holder
    private $memcached = null;

    // LoopUp package hgolder
    private $lookUpHolder = null;

    public function __construct($dbh)
    {
        // Set the Database holder
        $this->dbh = $dbh;

        // Turn on the SQL log
        // $this->dbh->inlineDebug = true;

        // Set the Memchaged holder
        $this->memcached = new Memcached();
        $this->memcached->addServer("127.0.0.1", 11211);

        // $this->memcached->flush();
        // die;

        // Set the Lookup package holder
        $this->lookUpHolder = new LookUp();
    }

    // Init function HaveDeals
    public function HaveDeals($videos)
    {
        // Get 2 Data from table Videos
       // $videos = $this->dbh->fetchAll("SELECT * FROM videos WHERE have_deals = '0' LIMIT 2");

        // Check if we have any videos to loop
        if(!empty($videos)){

            // Loop through the videos
            foreach ($videos as $video) {

                // Calling function ItunesDeals and giving parameter $video
                $check = $this->ItunesDeals($video);
                if ($check) {

                    // If $check return true update Videos set have_deals = 1
                    $update = $this->dbh->Execute("UPDATE videos SET have_deals = '1' WHERE video_id = :video_id", array('video_id' => $video["video_id"]));
                    if ($update) {

                        //If update successful echo
                        echo "\033[32m" ."Table 'videos' column 'have_deals' updated successful \033[0m\n";
                    } else {

                        //Else update error echo
                        echo "\033[31m" ."Table 'videos' column 'have_deals' update error \033[0m\n";
                    }
                }

            }
        }
        return true;
    }

    // Helper to clean the searched term
    private function cleanTerm($term){

        // Encode the term
        $term = urlencode($term);

        // remove repeated spaces
        return str_replace('++', '+', $term);

    }

    /**
     * Init function ItunesDeals
     * @param $video
     * @return bool
     */
    public function ItunesDeals($video)
    {

        // Check itunes Api Cache by name _itunes_api . video id
        $itunesSongs = $this->memcached->get("_itunes_api" . $video["video_id"]);
        if (empty($itunesSongs)) {

            // Set the term using the cleanTerm helper
            $term = $this->cleanTerm($video["title"]);

            // If empty fetch from Itunes Api with video title and set new cache
            $itunesSongs = $this->fetchSongs($term);

            $this->memcached->set("_itunes_api" . $video["video_id"], $itunesSongs, 86400);
        }

        // Init @param $counter
        $counter = 0;
        if(!empty($itunesSongs)){

            // Loop through the songs
            foreach ($itunesSongs as $itunesSong) {

                // Check itunes_deal table Cache by name _itunes_db . itunesCache['song_id']
                $itunes = $this->memcached->get("_itunes_db_" . $itunesSong["song_id"].'_'.$video['video_id']);

                //If emty Cache
                if (empty($itunes)) {

                    // Check table itunes_deal whether already song
                    $itunes = $this->dbh->Execute("SELECT video_id FROM itunes_deals WHERE video_id = :video_id AND song_id = :song_id", array('video_id' => $video["video_id"], 'song_id' => $itunesSong['songID']));

                    // Set Cache by name _itunes_db . itunesCache['song_id'] with value geting
                    $this->memcached->set("_itunes_db" . $itunesSong["song_id"].'_'.$video['video_id'], $itunes, 86400);
                }

                // If not exist in DB
                if (empty($itunes)) {

                    // trim artWorkUrl from Api
                    $artwork = trim($itunesSong["artworkUrl30"], "30x30bb.jpg");

                    // Insert new song in DB
                    $insert = $this->dbh->insert("itunes_deals", array(
                        "song_id" => $itunesSong["songID"],
                        "song_name" => $itunesSong["songName"],
                        "collection_name" => $itunesSong["collectionName"],
                        "album_id" => $itunesSong["albumID"],
                        "url_title" => $itunesSong["urlTitle"],
                        "artwork_url30" => empty($itunesSong["artworkUrl30"]) ? '0' : '1',
                        "artwork_url60" => empty($itunesSong["artworkUrl60"]) ? '0' : '1',
                        "artwork_url100" => empty($itunesSong["artworkUrl100"]) ? '0' : '1',
                        "artwork_url" => $artwork,
                        "video_id" => $video["video_id"]
                    ));

                    // If inserting successful @param $counter +1
                    if ($insert) {
                        echo "\033[35m" ."Insert in Table 'itunes_deals' successful\033[0m\n";
                        $counter += 1;
                    } else {
                        echo "\033[31m" ."Insert in Table 'itunes_deals' error\033[30m\n";
                    }
                }
            }
        }

        // If @param $counter > 0 return true
        return $counter > 0 ? true : false;
    }

    // Fetch songs from Apple API
    private function fetchSongs($term)
    {
        // 3 seconds sleep
        sleep(3);

        // Check if the term lenght is greater than 3
        if (strlen($term) > 3) {

            $a = $this->lookUpHolder->searchForSong($term);
            if (isset($a->results[0])) {

                // Create a result holder
                $result = array();

                // Check if the first song is not empty
                if(isset($a->results[0])){
                    $result[] = $this->lookUpHolder->songCleanUp($a->results[0]);
                }

                // Check if the second song is not empty
                if(isset($a->results[1])){
                    $result[] = $this->lookUpHolder->songCleanUp($a->results[1]);
                }

                // Check if the third song is not empty
                if(isset($a->results[2])){
                    $result[] = $this->lookUpHolder->songCleanUp($a->results[2]);
                }

                return $result;

            } else {

                // Find the last positon of '+' 
                $last_space_position = strrpos($term, '+');

                // Shorten the term
                $term = substr($term, 0, $last_space_position);

                // Try a new fetch
                return $this->fetchSongs($term);
            }
        }

    }

    // Helper for beautiful print
    private function prettyPrint($array)
    {
        echo '<pre>' . print_r($array, true) . '</pre>';
    }

}

// Turn on table debug
//$dbh->debugger = true;

$locker = new Locker('search_song.lock');

// Lock Cron
$locker->lock();
// Init Search class
$search = new Search($dbh);

$videos = $dbh->fetchAll("SELECT * FROM videos WHERE have_deals = '0' LIMIT 1000");
// Call function HaveDeals
$check = $search->HaveDeals($videos);
// Check
if ($check) {

    // Unlock Cron
    echo "Done\n";
    $locker->unlock();
}

// Show the table debug
//$dbh->showSQLDebugger();

?>
<?php

error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit','1024M');

// --------------------------------------------------------------
// Define the path to the framework folder.
// --------------------------------------------------------------
$frameworkPath = realpath(dirname(__FILE__). '/../..').'/_framework';

// --------------------------------------------------------------
// Define the path to the current application folder.
// --------------------------------------------------------------
$appPath = realpath(dirname(__FILE__). '/..');

include_once($frameworkPath.'/core/Paths.php');
include_once($frameworkPath.'/core/Database.php');
include_once($frameworkPath.'/core/Loader.php');

$dbSettings = Loader::loadConfig('dbSettings');
$dbh = Database::getInstance($dbSettings);

?>
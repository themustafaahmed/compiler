<?php

class DownloadController extends BaseController {
	
	public function action_index(){

		if(!empty($_SESSION['row_id'])){

			//$rowID = $_SESSION['row_id'];
            $rowID = filter_var($_SESSION['row_id'], FILTER_SANITIZE_STRING);
			unset($_SESSION['row_id']);

			//$videoInfo = $this->dbh->fetchRow('SELECT title, thumbnail, youtube_id FROM videos WHERE id='.$rowID);
            $videoInfo  = $this->memcached->get("videoInfo".$rowID);
            if(!$videoInfo){
                $_videoInfo = $this->dbh->fetchRow('SELECT title, thumbnail, youtube_id FROM videos WHERE id='.$rowID);
                $this->memcached->set("videoInfo".$rowID,$_videoInfo,10);
                $videoInfo = $_videoInfo;
            }
			Loader::loadCore('Encrypter', 'package');

			$this->EncrypterHolder = new Encrypter($this->siteSettings['encrypter_key']);

			$encrypted = array(
				'title' => $this->EncrypterHolder->encryptString($videoInfo['title']),
				'youtube_id' => $this->EncrypterHolder->encryptString($videoInfo['youtube_id']),
			);

			$videoInfo['title_save'] = addslashes($videoInfo['title']);

			//$popularVideos = $this->dbh->fetchAll("SELECT thumbnail,title,youtube_id FROM videos WHERE download_count > 3 AND is_converted = '1' ORDER BY RAND() LIMIT 4");

            $popularVideos  = $this->memcached->get("popularVideos1");
            if(!$videoInfo){
                $_popularVideos = $this->dbh->fetchAll("SELECT thumbnail,title,youtube_id FROM videos WHERE download_count > 3 AND is_converted = '1' ORDER BY RAND() LIMIT 4");
                $this->memcached->set("popularVideos1",$_popularVideos,86400);
                $popularVideos = $_popularVideos;
            }
			$this->smarty->assign('popularVideos', $popularVideos);

			$useragent=$_SERVER['HTTP_USER_AGENT'];
		if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4))){
				$this->smarty->assign('hideDownloadBtn', false);
		} else {
			$this->smarty->assign('hideDownloadBtn', true);
		}


			$this->smarty->assign('videoInfo', $videoInfo);
			$this->smarty->assign('current_index', 'download');
			$this->smarty->assign('encrypted', $encrypted);
			$this->smarty->display('download.tpl');

		} else {
			$this->redirect('/');
			exit();
		}
	}

	public function action_force(){

		Loader::loadCore('Encrypter', 'package');
		$this->EncrypterHolder = new Encrypter($this->siteSettings['encrypter_key']);

		$videoTitle = $this->EncrypterHolder->decryptString($_GET['t'], false);
		$videoId = $this->EncrypterHolder->decryptString($_GET['v'], false);

		if(!empty($videoTitle) && !empty($videoId)){

			$filePath = path('base').'storage/'.$videoId.'.mp3';
			if(file_exists($filePath)){

				$data = file_get_contents($filePath);

				header("Content-Disposition: attachment; filename=\"" . $videoTitle.'.mp3'. "\"");
				header("Content-Type: application/octet-stream");
				header("Content-Transfer-Encoding: Binary");
				header("Content-Length: " . strlen($data));
				header("Connection: close");

				// no cache
				header("Cache-Control: no-cache, must-revalidate");
				header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

				// IE fix (for HTTPS only) header('Cache-Control: private');
				// header('Pragma: private');

				echo $data;

			} else {
				$this->redirect('/');
			}
		} else {
			$this->redirect('/');
		}

	}

}

?>
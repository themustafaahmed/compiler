<?php

class ItunesController extends BaseController
{


    public function action_itunes()
    {
        // Filter id for sql injection security
        $video_id = filter_var($this->getParam['video_id'], FILTER_SANITIZE_NUMBER_INT);
        $song_id = filter_var($this->getParam['song_id'], FILTER_SANITIZE_NUMBER_INT);

        // Check Cache itunes deals video for current video id
        $itunes_deals_cache = $this->memcached->get('__song_id' . $song_id);

        //If empty
        if (empty($itunes_deals_cache)) {

            // Fetch data from Db with current video id
            $itunes_deals = $this->dbh->fetchRow("SELECT * FROM itunes_deals WHERE song_id=:song_id", array("song_id" => $song_id));

            // Set Cache with data getting from Db
            $this->memcached->set('__song_id' . $song_id, $itunes_deals, 86400);

            // @param $itunes_deals_cache equal to @param $itunes_deal
            $itunes_deals_cache = $itunes_deals;
        }

        if($itunes_deals_cache) {
            // Return @param $itunes_deals_cache
            return header('Location: https://geo.itunes.apple.com/us/album/' . $itunes_deals_cache["url_title"] . '/' . $itunes_deals_cache["album_id"] . '?i=' . $itunes_deals_cache["song_id"] . '&mt=1&app=music&at='.$this->siteSettings['itunes_affiliate_token'].'&ct=repeatproject');
        }else{
            echo "Not found music";
        }
        //$itunes_deals = "work";
        //$this->smarty->assign('itunes_deals', $itunes_deals);
        //$this->smarty->display('itunes_deals.tpl');
    }

}

?>
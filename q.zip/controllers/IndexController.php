<?php

class IndexController extends BaseController {
	
	public function action_index(){

		//$popularVideos = $this->dbh->fetchAll('SELECT * FROM videos WHERE status="active" ORDER BY views DESC LIMIT 16');

		/*$response = $this->memcached->get("Bilbo");
		if ($response) {
			echo $response;
		} else {
			echo "Adding Keys (K) for Values (V), You can then grab Value (V) for your Key (K) \m/ (-_-) \m/ ";
			$this->memcached->set("Bilbo", "Here s Your (Ring) Master stored in MemCached (^_^)", 10) or die(" Keys Couldn't be Created : Bilbo Not Found :'( ");
		}*/

		$popularVideos  = $this->memcached->get("popularVideos");
        if(!$popularVideos){
            $popularVideos = $this->dbh->fetchAll('SELECT * FROM videos WHERE status="active" ORDER BY views DESC LIMIT 16');
            $this->memcached->set("popularVideos",$popularVideos, 100);
        }

		$seo = array(
			'title' => 'Play YouTube Videos on Repeat | '.$this->siteSettings['name'],
			'description' => 'Play YouTube videos on repeat now! Loop the full video or just a section of it ✔ No registration required ✔ It\'s easy to use and absolutely free!',
			'keywords' => 'repeat youtube videos, automatically, youtube repeater, loop youtube videos, youtube repeat section, repeat part of youtube video,'.$this->siteSettings['name']
		);

		$this->smarty->assign('popularVideos', $popularVideos);
		$this->smarty->assign('token', $this->generateFormToken('index'));

		$this->smarty->assign('currentPage', 'index');
		$this->smarty->assign('seo', $seo);
		$this->smarty->display('home.tpl');

	}

}

?>
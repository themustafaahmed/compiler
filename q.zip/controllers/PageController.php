<?php

class PageController extends BaseController {
	
	public function action_route(){

		if(!empty($this->getParam['page'])){

			$allow = array('contact-us', 'how','privacy', 'about-us', 'insert');

			if(in_array($this->getParam['page'], $allow)){

				switch ($this->getParam['page']) {
					case 'contact-us':
						$pageFile = 'contact';
						$pageTitle = 'Contact us';
						break;
					case 'about-us':
						$pageTitle = 'About us';
						break;
					case 'how':
						$pageTitle = 'How to use';
						break;
					case 'privacy':
						$pageTitle = 'Privacy Policy';
						break;
					case 'error':
						$pageTitle = 'Error';
						break;
					case 'insert':
						
						// $in = array(
						// 	'title' => 'Wanderlust 🌲 - An Indie/Folk/Pop Playlist'
						// );
						// $this->dbh->inlineDebug = true;
						// $this->dbh->insert('testing_stuff', $in);
						// echo 5;
						die;

						break;
					
					default:
						$this::redirect('/404');
						break;
				}

				$seo = array(
					'title' => $pageTitle. ' | '.$this->siteSettings['name'],
					'description' => $pageTitle. ' '.$this->siteSettings['name'] 
				);

				$this->smarty->assign('seo', $seo);
				$this->smarty->assign('current_index', 'page');
				if(isset($pageFile)){
					$this->smarty->display('pages/'.$pageFile.'_page.tpl');
				} else {
					$this->smarty->display('pages/'.$this->getParam['page'].'_page.tpl');
				}
			}
		}

	}

}

?>
<?php

class AjaxController extends BaseController
{


    // Converts youtubeID to simple ID
    private function convertIntoNumber($youtubeID)
    {

         // Fetch the cached value
        $number = $this->memcached->get('to_number_'.$youtubeID);
        if (empty($number)) {
            $number = $this->dbh->fetchOne("SELECT video_id FROM videos WHERE youtube_id = :youtube_id", array('youtube_id' => $youtubeID));
            if (empty($number)) {
                if($this->dbh->insert('videos', array('youtube_id' => $youtubeID))){
                    $number = $this->dbh->lastInsertId();
                    // Set the cache for this video
                    $this->memcached->set('to_number_'.$youtubeID, $number, 0);
                } else {
                    $number = '';
                }

            } else {
                $this->memcached->set('to_number_'.$youtubeID, $number, 0);
            }
        }

        return $number;
    }


    // Trys to fetch the video information from cache or database
    private function getVideo($video_id, $time = 86400)
    {
        // Fetch the cached value
        $videoInfo = $this->memcached->get('video_'.$video_id);

        // Check if it's empty
        if (empty($videoInfo)) {

            // Fetch the video information from the database
            $videoInfo = $this->dbh->fetchRow("SELECT * FROM videos WHERE status = 'active' AND video_id = '" . $video_id . "'");
            
            // Check if the video holder is empty
            if (empty($videoInfo)) {
                return '';
            }

            // Set the cache for this video
            $this->memcached->set('video_'.$video_id, $videoInfo, $time);
        }

        // Return the video information
        return $videoInfo;
    }

    public function action_duration()
    {
        // Filters the sended param
        $videoID = filter_var($_POST['videoID'], FILTER_SANITIZE_STRING);

        // Check if the param is empty
        if (empty($videoID)) {

            // Convert the youtubeID to simpleID
            $video_id = $this->convertIntoNumber($videoID);

            if (empty($video_id)) {

                // Try to get the video from cache or database
                $videoInfo = $this->getVideo($video_id);

                if (!empty($videoInfo)) {
                    if ($_POST['startDuration'] >= 0 && $_POST['endDuration'] <= $videoInfo) {
                        $this->dbh->update('videos', array('start' => $_POST['startDuration'], 'end' => $_POST['endDuration']), "video_id = ".$video_id);
                    }
                }
            }
        }
    }

    public function action_encrypt()
    {
        $videoID = filter_var($_POST['videoID'], FILTER_SANITIZE_STRING);
        if (isset(/*$_POST['videoID']*/$videoID)) {
            $EncrypterHolder = new Core\Packages\Encrypter($this->siteSettings['encrypter_key']);
            $encryptedToken = $EncrypterHolder->encryptString(/*$_POST['videoID']*/
                $videoID . '#' . $_POST['startDuration'] . '#' . $_POST['endDuration']
            );
            exit(json_encode(array('status' => 'success', 'url' => $encryptedToken)));
        } else {
            exit(json_encode(array('status' => 'error')));
        }
    }

    public function action_fetch()
    {
        $verifyOne = $this->verifyFormToken('index');
        $verifyTwo = $this->verifyFormToken('common');
        if ($verifyOne == false && $verifyTwo == false) {
            $errorMessage = 'Your session has expired. Refresh and please try again :)';
            $_SESSION['error'] = $errorMessage;
            exit(json_encode(array('error' => $errorMessage)));
        }

        if (strtolower($_SERVER['REQUEST_METHOD']) == 'post') {
            if (empty($_POST['url'])) {
                $errorMessage = 'Empty video url';
                $_SESSION['error'] = $errorMessage;
                exit(json_encode(array('error' => $errorMessage)));
            }

            preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $_POST['url'], $match);

            if (!empty($match[1])) {
                $videoID = $match[1];

                // Convert the youtubeID to simpleID
                $video_id = $this->convertIntoNumber($videoID);

                // If the id is empty... exit
                if (empty($video_id)) {
                    die('Error: Num 1');
                }

                // Try to get the video from cache or database
                $videoInfo = $this->getVideo($video_id);

                if (empty($videoInfo)) {

                    // Load the YoutubeFetch package
                    $youtubeFetch = new Core\Packages\YoutubeFetch();

                    // Fetch the API keys
                    $youtubeApiKeys = $this->siteSettings['youtubeApiKeys'];

                    // Select a random key
                    $apiKey = $youtubeApiKeys[rand(0, count($youtubeApiKeys) - 1)];

                    // Fetch the video information from the api
                    $videoInfoApi = $youtubeFetch->getVideoInfoApi($videoID, $apiKey);

                    // Check if the video is `processed` and `public`
                    if ($videoInfoApi['uploadStatus'] == 'processed' && $videoInfoApi['privacyStatus'] == 'public') {

                        // Prepare the insert array
                        $insertArray = array('start' => 0,
                            'end' => 0,
                            'views' => 0,
                            'uploaderAvatar' => $videoInfoApi['uploaderAvatar'],
                            'duration' => $videoInfoApi['duration'],
                            'youtube_id' => $videoID,
                            'status' => 'active',
                            'title' => $videoInfoApi['title'],
                            'uploader' => $videoInfoApi['uploader'],
                            'upload_date' => $videoInfoApi['upload_date']
                        );

                        // Check if the insertion is successful
                        if ($this->dbh->update('videos', $insertArray, 'video_id='.$video_id)) {
                            $insertArray['video_id'] = $video_id;

                            // Set the video information
                            $videoInfo = $insertArray;

                            // Set the cache for this video's information
                            $this->memcached->set($video_id, $videoInfo, 86400);
                        } else {
                            die('insert error');
                        }
                    } else {
                        if (isset($videoInfo['error'])) {
                            $_SESSION['error'] = 'The video is not ready yet';
                            exit(json_encode(array('error' => $videoInfo['error'])));
                        }
                    }
                }

                if (isset($videoInfo['error'])) {
                    $_SESSION['error'] = $videoInfo['error'];
                    exit(json_encode(array('error' => $videoInfo['error'])));
                }

                exit(json_encode(array('success' => true, 'url' => $this->siteSettings['url'] . '/watch/' . $videoID)));
            } else {
                $errorMessage = 'Wrong url format';
                $_SESSION['error'] = $errorMessage;
                exit(json_encode(array('error' => $errorMessage)));
            }
        } else {
            $errorMessage = 'Go away hacker';
            $_SESSION['error'] = $errorMessage;
            exit(json_encode(array('error' => $errorMessage)));
        }
    }
}

<?php


class WatchController extends BaseController
{
    /*
        just video
        just video move start only
        just video move end only
        video with start only
        video with end only
        video with start and end
    */
    private $commonModel;

    public function init()
    {
        $this->commonModel = Loader::LoadModel('Common');
    }

    private function getViews($video_id)
    {
        $client_ip = $this->getRealIp();

        $cache = $this->memcached->get('view_' . $video_id . $client_ip);

        if (empty($cache)) {
            // endOfDay - the current time
            $expireAt = strtotime('23:59:59') - time();
            if ($expireAt > 0) {
                $this->dbh->Execute("UPDATE videos SET views = views + 1 WHERE video_id = '" . $video_id . "'");
                $this->memcached->set('view_' . $video_id . $client_ip, $expireAt);
            }
        }
    }

    private function getRealIp()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) //check ip from share internet
        {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) //to check ip is pass from proxy
        {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }

    // Trys to fetch the video information from cache or database
    private function getVideo($video_id, $time = 86400)
    {
        // Fetch the cached value
        $videoInfo = $this->memcached->get('video_' . $video_id);

        // Check if it's empty
        if (empty($videoInfo)) {

            // Fetch the video information from the database
            $videoInfo = $this->dbh->fetchRow("SELECT * FROM videos WHERE status = 'active' AND video_id = '" . $video_id . "'");

            // Check if the video holder is empty
            if (empty($videoInfo)) {
                return '';
            }

            // Set the cache for this video
            $this->memcached->set('video_' . $video_id, $videoInfo, $time);
        }

        // Return the video information
        return $videoInfo;
    }

    private function checkIfRelatedExist($videoID, $youtubeID, $time = 86400)
    {

        // Fetch the cached value
        $relatedExist = $this->memcached->get('related_' . $videoID . '_' . $youtubeID);
        // Check if it's empty
        if (empty($relatedVideosInfo)) {
            // Fetch the video information from the database
            $relatedExist = $this->dbh->fetchOne("SELECT video_id FROM related WHERE video_parent = :video_parent AND video_id = :video_id", array('video_parent' => $videoID, 'video_id' => $youtubeID));
            if (empty($relatedExist)) {
                return '';
            }

            // Set the cache for this video
            $this->memcached->set('related_' . $videoID . '_' . $youtubeID, true, $time);
        }

        return $relatedExist;
    }

    private function getVideoRelated($videoID, $time = 86400)
    {
        // Fetch the cached value
        $relatedVideosInfo = $this->memcached->get('related_' . $videoID);

        // Check if it's empty
        if (empty($relatedVideosInfo)) {

            // Fetch the video information from the database
            $relatedVideos = $this->dbh->column("SELECT video_id FROM related WHERE video_parent = :video_parent", array('video_parent' => $videoID));

            // Check if the video holder is empty
            if (empty($relatedVideos)) {
                return '';
            }

            $ids = "'" . implode("','", $relatedVideos) . "'";
            $relatedVideosInfo = $this->dbh->fetchAll("SELECT * FROM videos WHERE status='active' AND video_id IN($ids)");

            // Set the cache for this video
            $this->memcached->set('related_' . $videoID, $relatedVideosInfo, $time);
        }

        // Return the video information
        return $relatedVideosInfo;
    }

    /**
     * Init function itunes_deals
     * @param $video_id
     * @return mixed
     */
    public function itunes_deals($video_id)
    {
        // Filter id for sql injection security
        $video_id = filter_var($video_id, FILTER_SANITIZE_STRING);

        // Check Cache itunes deals video for current video id
        $itunes_deals_cache = $this->memcached->get('__itunes_deals__' . $video_id);

        //If empty
        if (empty($itunes_deals_cache)) {

            // Fetch data from Db with current video id
            $itunes_deals = $this->dbh->fetchAll("SELECT * FROM itunes_deals WHERE video_id=:video_id", array("video_id" => $video_id));

            // Set Cache with data getting from Db
            $this->memcached->set('__itunes_deals__' . $video_id, $itunes_deals, 86400);

            // @param $itunes_deals_cache equal to @param $itunes_deal
            $itunes_deals_cache = $itunes_deals;
        }

        // Return @param $itunes_deals_cache
        return $itunes_deals_cache;

    }

    public function action_index()
    {
        if (isset($_GET['flush'])) {
            $this->memcached->flush();
            die;
        }
        // $this->dbh->inlineDebug = true;

        // Filter the video param
        $videoID = filter_var($this->getParam['videoID'], FILTER_SANITIZE_STRING);

        // If it's empty
        if (empty($videoID)) {

            // Redict to home page
            $this->redirect($this->siteSettings['url']);
        }

        // Check if the start parameter is set
        if (isset($_GET['start'])) {

            // Check if negative number
            if ($_GET['start'] < 0) {

                // Redict to home page
                $this->redirect($this->siteSettings['url']);
            }
        }

        // Load the YoutubeFetch package
        $youtubeFetch = new Core\Packages\YoutubeFetch();

        // Fetch the API keys
        $youtubeApiKeys = $this->siteSettings['youtubeApiKeys'];

        // Select a random key
        $apiKey = $youtubeApiKeys[rand(0, count($youtubeApiKeys) - 1)];

        // Convert the youtubeID to simpleID
        $video_id = $this->commonModel->convertIntoNumber($videoID);

        // If the id is empty... exit
        if (empty($video_id)) {
            die('Error: Num 1');
        }

        // Try to get the video from cache or database
        $videoInfo = $this->getVideo($video_id, 86400);

        // Check if the video information is empty
        if (empty($videoInfo)) {

            // Fetch the video information from the api
            $videoInfoApi = $youtubeFetch->getVideoInfoApi($videoID, $apiKey, false);

            // Check if the video is `processed` and `public`
            if ($videoInfoApi['uploadStatus'] == 'processed' && $videoInfoApi['privacyStatus'] == 'public') {

                // Prepare the insert array
                $insertArray = array('start' => 0,
                    'end' => 0,
                    'views' => 0,
                    'uploaderAvatar' => $videoInfoApi['uploaderAvatar'],
                    'duration' => $videoInfoApi['duration'],
                    'youtube_id' => $videoID,
                    'status' => 'active',
                    'title' => $videoInfoApi['title'],
                    'uploader' => $videoInfoApi['uploader'],
                    'upload_date' => $videoInfoApi['upload_date']
                );

                if (!empty($insertArray['title']) && !empty($insertArray['uploaderAvatar'])) {

                    // Check if the insertion is successful
                    if ($this->dbh->update('videos', $insertArray, 'video_id=' . $video_id)) {
                        $insertArray['video_id'] = $video_id;

                        // Set the video information
                        $videoInfo = $insertArray;

                        // Set the cache for this video's information
                        $this->memcached->set($video_id, $videoInfo, 86400);
                    } else {
                        die('insert error');
                    }
                }
            } else {
                die('API error');
            }
        }

        if (empty($videoInfo)) {
            die('Error: Num 3');
        }

        if (!isset($videoInfo['video_id'])) {
            $videoInfo['video_id'] = $video_id;
        }

        // Update the video views
        $this->getViews($videoInfo['video_id']);

        // Try to get the video related videos from cache or database
        $relatedVideos = $this->getVideoRelated($videoInfo['video_id']);

        // If we don't have any data..
        if (empty($relatedVideos)) {

            // Fetch it from the API
            $related = $youtubeFetch->getRelatedToVideoIDApi($videoID, $apiKey, true);

            // Loop throught the API result
            foreach ($related as $_related) {

                
                $_video_id = $this->commonModel->convertIntoNumber($_related['id']);

                if (empty($_video_id)) {
                    die('Error: Num 2');
                }

                // Try to get the video from cache or database
                $check = $this->getVideo($_video_id);

                // If the video is new
                if (empty($check)) {

                    if (!isset($check['video_id'])) {
                        $check['video_id'] = $_video_id;
                    }

                    // Fetch additional information
                    $item = $youtubeFetch->getVideoInfoApi($_related['id'], $apiKey, false);

                    // Check if the video is `processed` and `public`
                    if ($item['uploadStatus'] == 'processed' && $item['privacyStatus'] == 'public') {

                        // Prepate the insert array
                        $insertRelatedArray = array(
                            'start' => 0,
                            'end' => 0,
                            'views' => 0,
                            'uploaderAvatar' => $item['uploaderAvatar'],
                            'duration' => $item['duration'],
                            'youtube_id' => $item['id'],
                            'title' => $item['title'],
                            'status' => 'active',
                            'uploader' => $item['uploader'],
                            'upload_date' => $item['upload_date']
                        );

                        // Try to insert the video
                        // Check if the insertion is successful
                        if ($this->dbh->update("videos", $insertRelatedArray, 'video_id=' . $_video_id)) {

                            // Check if the record already exist in cache or database
                            if (empty($this->checkIfRelatedExist($videoInfo['video_id'], $_video_id, 86400))) {

                                // Try to insert into related
                                // Check if the insertion is successful
                                if ($this->dbh->insert('related', array('video_parent' => $videoInfo['video_id'], 'video_id' => $_video_id))) {

                                    // Added to the final array holder
                                    $relatedVideos[] = $insertRelatedArray;
                                }
                            } else {
                                // echo 'not insert into related!!';
                                // Added to the final array holder
                                $relatedVideos[] = $insertRelatedArray;
                            }

                            // Set the cache for this video
                            $this->memcached->set('video_' . $_video_id, $insertRelatedArray, 86400);
                        }
                    }

                } else {

                    if (!isset($check['video_id'])) {
                        $check['video_id'] = $_video_id;
                    }

                    // Check if the record already exist in cache or database
                    if (empty($this->checkIfRelatedExist($videoInfo['video_id'], $check['video_id'], 86400))) {
                        if ($this->dbh->insert('related', array('video_parent' => $videoInfo['video_id'], 'video_id' => $check['video_id']))) {

                            // Added to the final array holder
                            $relatedVideos[] = $check;
                        }
                    } else {
                        // Added to the final array holder
                        $relatedVideos[] = $insertRelatedArray;
                    }
                }
            }

            // Check the the array is not empty
            if (!empty($relatedVideos)) {
                // Set the cache for the video
                $this->memcached->set('related_' . $videoInfo['video_id'], $relatedVideos, 86400);
            }
        }

        // Call function itunes_deals
        $itunes_deals = $this->itunes_deals($videoInfo['video_id']);

        $seo = array(
            'title' => $videoInfo['title'] . ' | ' . $this->siteSettings['name'],
            'description' => 'Listen on repeat ' . $videoInfo['title'] . ' on ' . $this->siteSettings['name'],
            'keywords' => 'repeat a youtube video, ' . $videoInfo['title'] . ', ' . $this->siteSettings['name']
        );

        // $this->memcached->delete('popularVideos');
        $EncrypterHolder = new Core\Packages\Encrypter($this->siteSettings['encrypter_key']);
        $encryptedToken = $EncrypterHolder->encryptString($videoInfo['youtube_id']);
        $popularVideos = $this->memcached->get("popularVideos");
        if (empty($popularVideos)) {
            $popularVideos = $this->dbh->fetchAll('SELECT * FROM videos WHERE status="active" ORDER BY views DESC LIMIT 16');
            $this->memcached->set("popularVideos", $popularVideos, 100);
        }

        // $this->prettyPrint($videoInfo);

        $this->smarty->assign('commonToken', $this->generateFormToken('common'));
        $this->smarty->assign('currentPage', 'watch');
        $this->smarty->assign('encryptedToken', $encryptedToken);
        $this->smarty->assign('videoInfo', $videoInfo);
        $this->smarty->assign('seo', $seo);
        $this->smarty->assign('related', $relatedVideos);
        $this->smarty->assign('popularVideos', $popularVideos);
        $this->smarty->assign('itunes_deals', $itunes_deals);
        $this->smarty->display('watch.tpl');
    }
}

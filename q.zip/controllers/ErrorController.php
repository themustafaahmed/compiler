<?php

class ErrorController extends BaseController {

	public function action_not_found(){
		$seo = array(
			'title' => '404 Nothing here | '.$this->siteSettings['name'],
		);
		header("HTTP/1.0 404 Not Found");

		$this->smarty->assign('seo', $seo);
		$this->smarty->display('pages/404.tpl');
	}

}

?>
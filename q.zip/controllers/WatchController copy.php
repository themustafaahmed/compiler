<?php

class WatchController extends BaseController
{
    /*
        just video
        just video move start only
        just video move end only
        video with start only
        video with end only
        video with start and end

    */

    private function getVideo($videoID, $time = 86400)
    {
        $videoInfo = $this->memcached->get($videoID);
        if (!$videoInfo) {
            $_videoInfo = $this->dbh->fetchRow("SELECT * FROM videos WHERE videoID = '" . $videoID . "'");
            $this->memcached->set($videoID, $_videoInfo, $time);
            $videoInfo = $_videoInfo;
        }
        return $videoInfo;
    }

    public function action_index()
    {
        // file_get_contents('http://repeat.eurocoders.com/watch/VIDEO/?start=0&end=207')
        // $videoID = $this->getParam['videoID'];
        $videoID = filter_var($this->getParam['videoID'], FILTER_SANITIZE_STRING);
        if (!$videoID) {
            return;
        }
        if (isset($_GET['start'])) {
            if ($_GET['start'] < 0) {
                $this->redirect($this->siteSettings['url']);
            }
        }

        $youtubeFetch = new Core\Packages\YoutubeFetch();
        $youtubeApiKeys = $this->siteSettings['youtubeApiKeys'];
        $apiKey = $youtubeApiKeys[rand(0, count($youtubeApiKeys) - 1)];

        $videoInfo = $this->getVideo($videoID, 100);
        if (empty($videoInfo)) {
            // $youtubeFetch->setYoutubeApiCacheDestination(path('base').'cache/youtubeApiInfo/');
            $videoInfo = $youtubeFetch->getVideoInfoApi($videoID, $apiKey, false);
            if ($videoInfo['uploadStatus'] == 'processed' && $videoInfo['privacyStatus'] == 'public') {
                $insertArray = array('start' => 0,
                    'end' => 0,
                    'views' => 0,
                    'uploaderAvatar' => $videoInfo['uploaderAvatar'],
                    'duration' => $videoInfo['duration'],
                    'videoID' => $videoID,
                    'title' => $videoInfo['title'],
                    'uploader' => $videoInfo['uploader'],
                    'upload_date' => $videoInfo['upload_date']);

                $this->prettyPrint($insertArray);
                $a = $this->dbh->insert('videos', $insertArray);

                if ($a) {
                    $videoInfo = $insertArray;
                } else {
                    exit('Sorry yo!');
                }
            } else {
                exit('Sorry yo!');
            }
        } else {
            $this->dbh->update('videos', array('views' => $videoInfo['views'] + 1), "videoID = '$videoID'");
        }

        $related = $this->memcached->get("related" . $videoID);
        if (empty($related)) {
            $related = $this->dbh->fetchAll("SELECT * FROM related WHERE main_id IN( '" . $videoID . "')");
            //$related = $this->dbh->fetchAll("SELECT SQL_NO_CACHE videos.* FROM videos INNER JOIN related ON related.video_id = videos.videoID WHERE main_id ='".$videoID."'");
        }

        if (empty($related)) {
            $related = $youtubeFetch->getRelatedToVideoIDApi($videoID, $apiKey, true);
            foreach ($related as $__related) {
                $check = $this->getVideo($__related['id']);
                if (empty($check)) {
                    $item = $youtubeFetch->getVideoInfoApi($__related['id'], $apiKey, false);
                    $this->dbh->insert("videos", array(
                        'start' => 0,
                        'end' => 0,
                        'views' => 0,
                        'uploaderAvatar' => $item['uploaderAvatar'],
                        'duration' => $item['duration'],
                        'videoID' => $item['id'],
                        'title' => $item['title'],
                        'uploader' => $item['uploader'],
                        'upload_date' => $item['upload_date']
                    ));
                }
                $this->dbh->insert('related', array('main_id' => $videoID, 'video_id' => $__related['id']));
                $this->memcached->set("related" . $videoID, $related, 86400);
            }
        } else {
            if ($related[0]["main_id"]) {
                $ids = null;
                foreach ($related as $_relatedApi) {
                    if ($ids == null)
                        $ids .= "'" . $_relatedApi['video_id'] . "'";
                    else
                        $ids .= ",'" . $_relatedApi['video_id'] . "'";
                }
                $related = $this->dbh->fetchAll("SELECT * FROM videos WHERE videoID IN( $ids)");
            }
            if ($related[0]["videoID"]) {
                $temp = array();
                foreach ($related as $key => $item) {
                    $temp[$key] = array(
                        "id" => $item["videoID"],
                        "title" => $item["title"],
                        "uploader" => $item["uploader"],
                        "upload_date" => $item["upload_date"],
                        "uploaderAvatar" => $item["uploaderAvatar"],
                        "views" => $item["views"],
                        "end" => $item["end"],
                        "start" => $item["start"]
                    );
                }
                $related = $temp;
            }
            $this->memcached->set("related" . $videoID, $related, 86400);
        }

        // $this->prettyPrint($temp);
        // $this->dbh->inlineDebug = true;
        $seo = array(
            'title' => $videoInfo['title'] . ' | ' . $this->siteSettings['name'],
            'description' => 'Listen on repeat ' . $videoInfo['title'] . ' on ' . $this->siteSettings['name'],
            'keywords' => 'repeat a youtube video, ' . $videoInfo['title'] . ', ' . $this->siteSettings['name']
        );

        $EncrypterHolder = new Core\Packages\Encrypter($this->siteSettings['encrypter_key']);
        $encryptedToken = $EncrypterHolder->encryptString($videoInfo['videoID']);
        $popularVideos = $this->memcached->get("popularVideos");
        if (!$popularVideos) {
            $_popularVideos = $this->dbh->fetchAll('SELECT * FROM videos WHERE status="active" ORDER BY views DESC LIMIT 16');
            $this->memcached->set("popularVideos", $_popularVideos, 10);
            $popularVideos = $_popularVideos;
        }
        $this->smarty->assign('commonToken', $this->generateFormToken('common'));
        $this->smarty->assign('currentPage', 'watch');
        $this->smarty->assign('encryptedToken', $encryptedToken);
        $this->smarty->assign('videoInfo', $videoInfo);
        $this->smarty->assign('seo', $seo);
        $this->smarty->assign('related', $related);
        $this->smarty->assign('popularVideos', $popularVideos);
        $this->smarty->display('watch.tpl');

    }

}

?>
<?php

// --------------------------------------------------------------
// Site Settings
// --------------------------------------------------------------
return array (
	'name'          => 'repeat',
	'domain'        => 'repeat.eurocoders.com',
	'not_found'     => 'http://repeat.eurocoders.com/error/404',
	'url'           => 'http://repeat.eurocoders.com',
	'img'           => 'http://repeat.eurocoders.com/public/img',
	'css'           => 'http://repeat.eurocoders.com/public/css',
	'js'            => 'http://repeat.eurocoders.com/public/js',
	'version'       => '1.0',
	'encrypter_key' => 'ideabox12ideabox',
	'itunes_affiliate_token' => '1001lQcS',
	'youtubeApiKeys' => array(
		'AIzaSyAXFOFJsKc_YSSdgqrXzocvTWPfRa40Qt0'
	),
);

?>
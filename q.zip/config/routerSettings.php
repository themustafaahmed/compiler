<?php

$rules = array(

	// post requests only
	'post' => array(
		
		'/ajax/fetch' => array(
			'controller' => 'Ajax', 'action' => 'fetch'
		),
		'/ajax/duration' => array(
			'controller' => 'Ajax', 'action' => 'duration'
		),
		'/ajax/encrypt' => array(
			'controller' => 'Ajax', 'action' => 'encrypt'
		),
	),
	
	// get requests only
	'get' => array(

		'/error/404' => array(
			'controller' => 'error', 'action' => 'not_found',
		),
		'/' => array(
			'controller' => 'Index', 'action' => 'index',
		),
		'/watch/{videoID:(.*?)+}' => array(
			'controller' => 'Watch', 'action' => 'index',
		),
		'/download/force' => array(
			'controller' => 'Download', 'action' => 'force',
		),
		'/page/{page:(.*?)+}' => array(
			'controller' => 'Page', 'action' => 'route',
		),
        '/out/{song_id:(.*?)+}/{video_id:(.*?)+}' => array(
            'controller' => 'Itunes', 'action' => 'itunes',
        ),
		
	)

);

return $rules[strtolower($_SERVER['REQUEST_METHOD'])];

?>
<?php

return array(
	// 'connection_uri_socket' => 'mysql:unix_socket=/var/lib/mysql/mysql.sock;dbname=instragrameurocoders',
	'connection_uri' => 'mysql:host=localhost;dbname=repeateurocoders',
	'username' => 'repeat',
	'password' => 'repeat13',
	'encode' => 'utf8mb4',
);

?>